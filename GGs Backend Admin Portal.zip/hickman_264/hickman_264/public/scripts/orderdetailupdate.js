var OrderDetailUpdateBox = React.createClass({
    getInitialState: function () {
        return { data: [] };
    },

    loadOrderDetailFromServer: function () {
        $.ajax({
            url: '/orderdetailsearch',
            data: {
                'orderdetailkey': orderdetailkey.value,
                'orderkey': orderkey.value,
                'mitemkey': mitemkey.value,
                'itemquantity': itemquantity.value,
            },
            dataType: 'json',
            cache: false,
            success: function (data) {
                this.setState({ data: data });
            }.bind(this),
            error: function (xhr, status, err) {
                console.error(this.props.url, status, err.toString());
            }.bind(this)
        });

    },
    updateSingleOrderDetailFromServer: function (OrderDetail) {
        $.ajax({
            url: '/getsingleorderdetail',
            dataType: 'json',
            data: OrderDetail,
            type: 'POST',
            cache: false,
            success: function (upsingledata) {
                this.setState({ upsingledata: upsingledata });
            }.bind(this),
            error: function (xhr, status, err) {
                console.error(this.props.url, status, err.toString());
            }.bind(this)
        });
        window.location.reload(true);
    },
    componentDidMount: function () {
        this.loadOrderDetailFromServer();
    },

    render: function () {
        return (
            <div>
                <OrderDetailUpdateForm onOrderDetailSubmit={this.loadOrderDetailFromServer} />
                <br />
                <div id="theresults">
                    <div id="theleft">
                        <table>
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Orderkey</th>
                                    <th>Menu Item Key</th>
                                    <th>Item Quantity</th>
                                </tr>
                            </thead>
                            <OrderDetailList data={this.state.data} />
                        </table>
                    </div>
                    <div id="theright">
                        <OrderDetailUpdateform onUpdateSubmit={this.updateSingleOrderDetailFromServer} />
                    </div>
                </div>
            </div>
        );
    }
});

var OrderDetailUpdateForm = React.createClass({
    getInitialState: function () {
        return {
            orderdetailkey: "",
            orderkey: "",
            mitemkey: "",
            itemquantity: "",
            data: []
        };
    },

    handleSubmit: function (e) {
        e.preventDefault();

        var orderdetailkey = this.state.orderdetailkey.trim();
        var orderkey = this.state.orderkey.trim();
        var mitemkey = this.state.mitemkey.trim();
        var itemquantity = this.state.itemquantity.trim();

        this.props.onOrderDetailSubmit({
            orderdetailkey: orderdetailkey,
            orderkey: orderkey,
            mitemkey: mitemkey,
            itemquantity: itemquantity
        });
    },
    handleChange: function (event) {
        this.setState({
            [event.target.id]: event.target.value
        });
    },

    render: function () {
        return (
            <center>
                <form onSubmit={this.handleSubmit}>

                    <table border>
                        <tbody>
                            <tr>
                                <th>OrderDetail Item ID</th>
                                <td>
                                    <input name="orderdetailkey" id="orderdetailkey"
                                        value={this.state.orderdetailkey} onChange={this.handleChange} />
                                </td>
                            </tr>

                            <tr>
                                <th>Order Key</th>
                                <td>
                                    <input name="orderkey" id="orderkey"
                                        value={this.state.orderkey} onChange={this.handleChange} />
                                </td>
                            </tr>
                            <tr>
                                <th>Menu Item Key</th>
                                <td>
                                    <input name="mitemkey" id="mitemkey"
                                        value={this.state.mitemkey} onChange={this.handleChange} />
                                </td>
                            </tr>

                            <tr>
                                <th>Item Quantity</th>
                                <td>
                                    <input name="iteamquantity" id="itemquantity"
                                        value={this.state.itemquantity} onChange={this.handleChange} />
                                </td>
                            </tr>
                        </tbody>
                    </table><br />
                    <input type="submit" name="thesubmit" value="Search" id="thesubmit" />
                </form>

                <div>
                    <br />
                    <form onSubmit={this.getInitialState}>
                        <input type="submit" value="Reset Forms" />
                    </form>
                </div>
            </center>
        );
    }
});

var OrderDetailUpdateform = React.createClass({
    getInitialState: function () {
        return {
            upOrderdetailkey: "",
            upOrderkey: "",
            upMitemkey: "",
            upItemquantity: "",
            updata: []
        };
    },

    handleUpSubmit: function (e) {
        e.preventDefault();

        var upOrderdetailkey = orderdetailkey.value;
        var upOrderkey = orderkey.value;
        var upMitemkey = mitemkey.value;
        var upItemquantity = itemquantity.value;

        this.props.onUpdateSubmit({
            upOrderdetailkey: upOrderdetailkey,
            upOrderkey: upOrderkey,
            upMitemkey: upMitemkey,
            upItemquantity: upItemquantity
        });

    },
    handleUpChange: function (event) {
        this.setState({
            [event.target.id]: event.target.value
        });
    },
    render: function () {

        return (
            <center>
                <div>
                    <div id="theform">
                        <form onSubmit={this.handleUpSubmit}>

                            <table>
                                <tbody>
                                    <tr>
                                        <th>OrderDetail Item ID</th>
                                        <td>
                                            <input name="upOrderdetailkey" id="upOrderdetailkey"
                                                value={this.state.upOrderdetailkey} onChange={this.handleChange} />
                                        </td>
                                    </tr>

                                    <tr>
                                        <th>Order Key</th>
                                        <td>
                                            <input name="upOrderkey" id="upOrderkey"
                                                value={this.state.upOrderkey} onChange={this.handleChange} />
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>Menu Item Key</th>
                                        <td>
                                            <input name="upMitemkey" id="upMitemkey"
                                                value={this.state.upMitemkey} onChange={this.handleChange} />
                                        </td>
                                    </tr>

                                    <tr>
                                        <th>Item Quantity</th>
                                        <td>
                                            <input name="upItemquantity" id="upItemquantity"
                                                value={this.state.upItemquantity} onChange={this.handleChange} />
                                        </td>
                                    </tr>
                                </tbody>
                            </table><br />
                            <input type="hidden" name="upOrderdetailkey" id="upOrderdetailkey" onChange={this.handleUpChange} />
                            <input type="submit" id="theupdate" value="Update" />
                        </form>
                    </div>
                </div></center>
        );
    }
});

var OrderDetailList = React.createClass({
    render: function () {
        var OrderDetailNodes = this.props.data.map(function (OrderDetail) {
            return (
                <OrderDetail
                    key={OrderDetail.orderdetailkey}
                    ordkey={OrderDetail.orderkey}
                    mikey={OrderDetail.mitemkey}
                    iq={OrderDetail.itemquantity}
                >
                </OrderDetail>
            );
        });
        return (
            <tbody>
                {OrderDetailNodes}
            </tbody>
        );
    }
});

var OrderDetail = React.createClass({
    getInitialState: function () {
        return {
            upOrderdetailkey: "",
            singledata: []
        };
    },
    updateRecord: function (e) {
        e.preventDefault();
        var theupOrderdetailkey = this.props.orderdetailkey;

        this.loadSingleEmp(theupOrderdetailkey);
    },
    loadSingleEmp: function (theupOrderdetailkey) {
        $.ajax({
            url: '/getsingleorderdetail',
            data: {
                'upOrderdetailkey': theupOrderdetailkey
            },
            dataType: 'json',
            cache: false,
            success: function (data) {
                this.setState({ singledata: data });
                console.log(this.state.singledata);
                var populateEmp = this.state.singledata.map(function (OrderDetail) {
                    upOrderdetailkey.value = theupOrderdetailkey;
                    upOrderkey.value = OrderDetail.orderkey;
                    upMitemkey.value = OrderDetail.mitemkey;
                    upItemquantity.value = OrderDetail.itemquantity;
                });
            }.bind(this),
            error: function (xhr, status, err) {
                console.error(this.props.url, status, err.toString());
            }.bind(this)
        });
    },

    render: function () {

        return (

            <tr>
                <td>
                    {this.props.key}
                </td>
                <td>
                    {this.props.ordkey}
                </td>
                <td>
                    {this.props.mikey}
                </td>
                <td>
                    {this.props.iq}
                </td>
                <td>
                    <form onSubmit={this.updateRecord}>

                        <input type="submit" value="Edit" />
                    </form>
                </td>
            </tr>
        );
    }
});


ReactDOM.render(
    <OrderDetailUpdateBox />,
    document.getElementById('content')
);


var UserUpdateBox = React.createClass({
    getInitialState: function () {
        return { data: [] };
    },

    loadUserFromServer: function () {
        $.ajax({
            url: '/usersearch',
            data: {
                'userid': userid.value,
                'employeeid': employeeid.value,
                'username': username.value,
                'password': password.value,
                'seclvl': seclvl.value,
            },
            dataType: 'json',
            cache: false,
            success: function (data) {
                this.setState({ data: data });
            }.bind(this),
            error: function (xhr, status, err) {
                console.error(this.props.url, status, err.toString());
            }.bind(this)
        });

    },
    updateSingleUserFromServer: function (User) {
        $.ajax({
            url: '/getsingleuser',
            dataType: 'json',
            data: User,
            type: 'POST',
            cache: false,
            success: function (upsingledata) {
                this.setState({ upsingledata: upsingledata });
            }.bind(this),
            error: function (xhr, status, err) {
                console.error(this.props.url, status, err.toString());
            }.bind(this)
        });
        window.location.reload(true);
    },
    componentDidMount: function () {
        this.loadUserFromServer();
    },

    render: function () {
        return (
            <div>
                <UserUpdateForm onUserSubmit={this.loadUserFromServer} />
                <br />
                <div id="theresults">
                    <div id="theleft">
                        <table>
                            <thead>
                                <tr>
                                    <th>User ID</th>
                                    <th>Employee ID</th>
                                    <th>Username</th>
                                    <th>Password</th>
                                    <th>Security Level</th>
                                </tr>
                            </thead>
                            <UserList data={this.state.data} />
                        </table>
                    </div>
                    <div id="theright">
                        <UserUpdateform onUpdateSubmit={this.updateSingleUserFromServer} />
                    </div>
                </div>
            </div>
        );
    }
});

var UserUpdateForm = React.createClass({
    getInitialState: function () {
        return {
            userid: "",
            employeeid: "",
            username: "",
            password: "",
            seclvl: "",
            data: []
        };
    },

    handleSubmit: function (e) {
        e.preventDefault();

        var userid = this.state.userid.trim();
        var employeeid = this.state.employeeid.trim();
        var username = this.state.username.trim();
        var password = this.state.password.trim();
        var seclvl = this.state.seclvl.trim();

        this.props.onUserSubmit({
            userid: userid,
            employeeid: employeeid,
            username: username,
            password: password,
            seclvl: seclvl,
        });
    },
    handleChange: function (event) {
        this.setState({
            [event.target.id]: event.target.value
        });
    },

    render: function () {
        return (
            <center>
                <form onSubmit={this.handleSubmit}>

                    <table bUser>
                        <tbody>
                            <tr>
                                <th>User ID</th>
                                <td>
                                    <input name="userid" id="userid"
                                        value={this.state.userid} onChange={this.handleChange} />
                                </td>
                            </tr>

                            <tr>
                                <th>Employee ID</th>
                                <td>
                                    <input name="employeeid" id="employeeid"
                                        value={this.state.employeeid} onChange={this.handleChange} />
                                </td>
                            </tr>
                            <tr>
                                <th>Username</th>
                                <td>
                                    <input name="username" id="username"
                                        value={this.state.username} onChange={this.handleChange} />
                                </td>
                            </tr>

                            <tr>
                                <th>Password</th>
                                <td>
                                    <input name="password" id="password"
                                        value={this.state.password} onChange={this.handleChange} />
                                </td>
                            </tr>

                            <tr>
                                <th>Security Level</th>
                                <td>
                                    <input name="seclvl" id="seclvl"
                                        value={this.state.seclvl} onChange={this.handleChange} />
                                </td>
                            </tr>
                        </tbody>
                    </table><br />
                    <input type="submit" name="thesubmit" value="Search" id="thesubmit" />
                </form>

                <div>
                    <br />
                    <form onSubmit={this.getInitialState}>
                        <input type="submit" value="Reset Forms" />
                    </form>
                </div>
            </center>
        );
    }
});

var UserUpdateform = React.createClass({
    getInitialState: function () {
        return {
            upUserid: "",
            upEmployeeid: "",
            upUsername: "",
            upPassword: "",
            upSeclvl: "",
            updata: []
        };
    },

    handleUpSubmit: function (e) {
        e.preventDefault();

        var upUserid = userid.value;
        var upEmployeeid = employeeid.value;
        var upUsername = username.value;
        var upPassword = password.value;
        var upSeclvl = seclvl.value;

        this.props.onUpdateSubmit({
            upUserid: upUserid,
            upEmployeeid: upEmployeeid,
            upUsername: upUsername,
            upPassword: upPassword,
            upSeclvl: upSeclvl,
        });

    },
    handleUpChange: function (event) {
        this.setState({
            [event.target.id]: event.target.value
        });
    },
    render: function () {

        return (
            <center>
                <div>
                    <div id="theform">
                        <form onSubmit={this.handleUpSubmit}>

                            <table>
                                <tbody>
                                    <tr>
                                        <th>User ID</th>
                                        <td>
                                            <input name="upUserid" id="upUserid"
                                                value={this.state.upUserid} onChange={this.handleChange} />
                                        </td>
                                    </tr>

                                    <tr>
                                        <th>Employee ID</th>
                                        <td>
                                            <input name="upEmployeeid" id="upEmployeeid"
                                                value={this.state.upEmployeeid} onChange={this.handleChange} />
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>Username</th>
                                        <td>
                                            <input name="upUsername" id="upUsername"
                                                value={this.state.upUsername} onChange={this.handleChange} />
                                        </td>
                                    </tr>

                                    <tr>
                                        <th>Password</th>
                                        <td>
                                            <input name="upPassword" id="upPassword"
                                                value={this.state.upPassword} onChange={this.handleChange} />
                                        </td>
                                    </tr>

                                    <tr>
                                        <th>Security Level</th>
                                        <td>
                                            <input name="upSeclvl" id="upSeclvl"
                                                value={this.state.upSeclvl} onChange={this.handleChange} />
                                        </td>
                                    </tr>
                                </tbody>
                            </table><br />
                            <input type="hidden" name="upUserid" id="upUserid" onChange={this.handleUpChange} />
                            <input type="submit" id="theupdate" value="Update" />
                        </form>
                    </div>
                </div></center>
        );
    }
});

var UserList = React.createClass({
    render: function () {
        var UserNodes = this.props.data.map(function (User) {
            return (
                <User
                    key={User.userid}
                    eid={User.employeeid}
                    un={User.username}
                    pass={User.password}
                    slvl={User.seclvl}
                >
                </User>
            );
        });
        return (
            <tbody>
                {UserNodes}
            </tbody>
        );
    }
});

var User = React.createClass({
    getInitialState: function () {
        return {
            upUserid: "",
            singledata: []
        };
    },
    updateRecord: function (e) {
        e.preventDefault();
        var theupUserid = this.props.userid;

        this.loadSingleEmp(theupUserid);
    },
    loadSingleEmp: function (theupUserid) {
        $.ajax({
            url: '/getsingleUser',
            data: {
                'upUserid': theupEmployeeid
            },
            dataType: 'json',
            cache: false,
            success: function (data) {
                this.setState({ singledata: data });
                console.log(this.state.singledata);
                var populateEmp = this.state.singledata.map(function (User) {
                    upUserid.value = theupUserid;
                    upEmployeeid.value = User.employeeid;
                    upUsername.value = User.username;
                    upPassword.value = User.password;
                    upSeclvl.value = User.seclvl;
                });
            }.bind(this),
            error: function (xhr, status, err) {
                console.error(this.props.url, status, err.toString());
            }.bind(this)
        });
    },

    render: function () {

        return (

            <tr>
                <td>
                    {this.props.key}
                </td>
                <td>
                    {this.props.eid}
                </td>
                <td>
                    {this.props.un}
                </td>
                <td>
                    {this.props.pass}
                </td>
                <td>
                    {this.props.slvl}
                </td>
                <td>
                    <form onSubmit={this.updateRecord}>

                        <input type="submit" value="Edit" />
                    </form>
                </td>
            </tr>
        );
    }
});


ReactDOM.render(
    <UserUpdateBox />,
    document.getElementById('content')
);
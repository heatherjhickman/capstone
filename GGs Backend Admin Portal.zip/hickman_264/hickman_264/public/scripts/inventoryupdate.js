var InventoryUpdateBox = React.createClass({
    getInitialState: function () {
        return { data: [] };
    },

    loadInventoryFromServer: function () {
        $.ajax({
            url: '/inventorysearch',
            data: {
                'invid': invid.value,
                'invname': invname.value,
                'invdescrip': invdescrip.value,
                'invunitprice': invunitprice.value,
                'invindate': invindate.value,
                'invoutdate': invoutdate.value,
                'invquantityinstock': invquantityinstock.value,
                'invsupplier': invsupplier.value,
            },
            dataType: 'json',
            cache: false,
            success: function (data) {
                this.setState({ data: data });
            }.bind(this),
            error: function (xhr, status, err) {
                console.error(this.props.url, status, err.toString());
            }.bind(this)
        });

    },
    updateSingleInventoryFromServer: function (Inventory) {
        $.ajax({
            url: '/getsingleinvitem',
            dataType: 'json',
            data: Inventory,
            type: 'POST',
            cache: false,
            success: function (upsingledata) {
                this.setState({ upsingledata: upsingledata });
            }.bind(this),
            error: function (xhr, status, err) {
                console.error(this.props.url, status, err.toString());
            }.bind(this)
        });
        window.location.reload(true);
    },
    componentDidMount: function () {
        this.loadInventoryFromServer();
    },

    render: function () {
        return (
            <div>
                <InventoryUpdateForm onInventorySubmit={this.loadInventoryFromServer} />
                <br />
                <div id="theresults">
                    <div id="theleft">
                        <table>
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Description</th>
                                    <th>Price</th>
                                    <th>In-Date</th>
                                    <th>Out-Date</th>
                                    <th>Quantity</th>
                                    <th>Supplier</th>
                                </tr>
                            </thead>
                            <InventoryList data={this.state.data} />
                        </table>
                    </div>
                    <div id="theright">
                        <InventoryUpdateform onUpdateSubmit={this.updateSingleInventoryFromServer} />
                    </div>
                </div>
            </div>
        );
    }
});

var InventoryUpdateForm = React.createClass({
    getInitialState: function () {
        return {
            invid: "",
            invname: "",
            invdescrip: "",
            invunitprice: "",
            invindate: "",
            invoutdate: "",
            invquantityinstock: "",
            invsupplier: "",
            data: []
        };
    },

    submithandle: function (e) {
        e.preventDefault();

        var invid = this.state.invid.trim();
        var invname = this.state.invname.trim();
        var invdescrip = this.state.invdescrip.trim();
        var invunitprice = this.state.invunitprice.trim();
        var invindate = this.state.invindate.trim();
        var invoutdate = this.state.invoutdate.trim();
        var invquantityinstock = this.state.invquantityinstock.trim();
        var invsupplier = this.state.invsupplier.trim();

        this.props.onInventorySubmit({
            invid: invid,
            invname: invname,
            invdescrip: invdescrip,
            invunitprice: invunitprice,
            invindate: invindate,
            invoutdate: invoutdate,
            invquantityinstock: invquantityinstock,
            invsupplier: invsupplier
        });
    },
    handleChange: function (event) {
        this.setState({
            [event.target.id]: event.target.value
        });
    },
    render: function () {

        return (
            <center>
                <form onSubmit={this.submithandle}>

                    <table border>
                        <tbody>
                            <tr>
                                <th>Inventory ID</th>
                                <td>
                                    <input name="invid" id="invid"
                                        value={this.state.invid} onChange={this.handleChange} />
                                </td>
                            </tr>

                            <tr>
                                <th>Inventory Name</th>
                                <td>
                                    <input name="invname" id="invname"
                                        value={this.state.invname} onChange={this.handleChange} />
                                </td>
                            </tr>
                            <tr>
                                <th>Inventory Description</th>
                                <td>
                                    <input name="invdescrip" id="invdescrip"
                                        value={this.state.invdescrip} onChange={this.handleChange} />
                                </td>
                            </tr>

                            <tr>
                                <th>Inventory Unit Price</th>
                                <td>
                                    <input name="invunitprice" id="invunitprice"
                                        value={this.state.invunitprice} onChange={this.handleChange} />
                                </td>
                            </tr>

                            <tr>
                                <th>Inventory In-Date</th>
                                <td>
                                    <input name="invindate" id="invindate"
                                        value={this.state.invindate} onChange={this.handleChange} />
                                </td>
                            </tr>

                            <tr>
                                <th>Inventory Out-Date</th>
                                <td>
                                    <input name="invoutdate" id="invoutdate"
                                        value={this.state.invoutdate} onChange={this.handleChange} />
                                </td>
                            </tr>

                            <tr>
                                <th>Inventory Quantity</th>
                                <td>
                                    <input name="invquantityinstock" id="invquantityinstock"
                                        value={this.state.invquantityinstock} onChange={this.handleChange} />
                                </td>
                            </tr>

                            <tr>
                                <th>Inventory Supplier</th>
                                <td>
                                    <input name="invsupplier" id="invsupplier"
                                        value={this.state.invsupplier} onChange={this.handleChange} />
                                </td>
                            </tr>
                        </tbody>
                    </table><br />
                    <input type="submit" name="thesubmit" value="Update" id="thesubmit" />
                </form>

                <div>
                    <br />
                    <form onSubmit={this.getInitialState}>
                        <input type="submit" value="Reset Forms" />
                    </form>
                </div>
            </center>
        );
    }
});

var InventoryUpdateform = React.createClass({
    getInitialState: function () {
        return {
            upInvid: "",
            upInvname: "",
            upInvdescrip: "",
            upInvunitprice: "",
            upInvindate: "",
            upInvoutdate: "",
            upInvquantityinstock: "",
            upInvsupplier: "",
            updata: []
        };
    },

    handleUpSubmit: function (e) {
        e.preventDefault();

        var upInvid = invid.value;
        var upInvname = invname.value;
        var upInvdescrip = invdescrip.value;
        var upInvunitprice = invunitprice.value;
        var upInvindate = invindate.value;
        var upInvoutdate = invoutdate.value;
        var upInvquantityinstock = invquantityinstock.value;
        var upInvsupplier = invsupplier.value;


        this.props.onUpdateSubmit({
            upInvid: upInvid,
            upInvname: upInvname,
            upInvdescrip: upInvdescrip,
            upInvunitprice: upInvunitprice,
            upInvindate: upInvindate,
            upInvoutdate: upInvoutdate,
            upInvquantityinstock: upInvquantityinstock,
            upInvsupplier: upInvsupplier
        });

    },
    handleUpChange: function (event) {
        this.setState({
            [event.target.id]: event.target.value
        });
    },
    render: function () {

        return (
            <center>
                <div>
                    <div id="theform">
                        <form onSubmit={this.handleUpSubmit}>

                            <table>
                                <tbody>
                                    <tr>
                                        <th>Inventory ID</th>
                                        <td>
                                            <input name="upInvid" id="upInvid"
                                                value={this.state.upInvid} onChange={this.handleChange} />
                                        </td>
                                    </tr>

                                    <tr>
                                        <th>Inventory Name</th>
                                        <td>
                                            <input name="upInvfname" id="upInvfname"
                                                value={this.state.upInvfname} onChange={this.handleChange} />
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>Inventory Description</th>
                                        <td>
                                            <input name="upInvdescrip" id="upInvdescrip"
                                                value={this.state.upInvdescrip} onChange={this.handleChange} />
                                        </td>
                                    </tr>

                                    <tr>
                                        <th>Inventory Unit Price</th>
                                        <td>
                                            <input name="upInvunitprice" id="upInvunitprice"
                                                value={this.state.upInvunitprice} onChange={this.handleChange} />
                                        </td>
                                    </tr>

                                    <tr>
                                        <th>Inventory In-Date</th>
                                        <td>
                                            <input name="upInvindate" id="upInvindate"
                                                value={this.state.upInvindate} onChange={this.handleChange} />
                                        </td>
                                    </tr>

                                    <tr>
                                        <th>Inventory Out-Date</th>
                                        <td>
                                            <input name="upInvoutdate" id="upInvoutdate"
                                                value={this.state.upInvoutdate} onChange={this.handleChange} />
                                        </td>
                                    </tr>

                                    <tr>
                                        <th>Inventory Quantity</th>
                                        <td>
                                            <input name="upInvquantityinstock" id="upInvquantityinstock"
                                                value={this.state.upInvquantityinstock} onChange={this.handleChange} />
                                        </td>
                                    </tr>

                                    <tr>
                                        <th>Inventory Supplier</th>
                                        <td>
                                            <input name="upInvsupplier" id="upInvsupplier"
                                                value={this.state.upInvsupplier} onChange={this.handleChange} />
                                        </td>
                                    </tr>
                                </tbody>
                            </table><br />
                            <input type="hidden" name="upInvid" id="upInvid" onChange={this.handleUpChange} />
                            <input type="submit" id="theupdate" value="Update" />
                        </form>
                    </div>
                </div></center>
        );
    }
});

var InventoryList = React.createClass({
    render: function () {
        var InventoryNodes = this.props.data.map(function (Inventory) {
            return (
                <Inventory
                    key={Inventory.invid}
                    iname={Inventory.invname}
                    idesc={Inventory.invdescrip}
                    iprice={Inventory.invunitprice}
                    iidate={Inventory.invindate}
                    iodate={Inventory.invoutdate}
                    iqst={Inventory.invquantityinstock}
                    isup={Inventory.invsupplier}
                >
                </Inventory>
            );
        });
        return (
            <tbody>
                {InventoryNodes}
            </tbody>
        );
    }
});

var Inventory = React.createClass({
    getInitialState: function () {
        return {
            upInvid: "",
            singledata: []
        };
    },
    updateRecord: function (e) {
        e.preventDefault();
        var theupInvid = this.props.cusid;

        this.loadSingleEmp(theupInvid);
    },
    loadSingleEmp: function (theupInvid) {
        $.ajax({
            url: '/getsingleInventory',
            data: {
                'upInvid': theupInvid
            },
            dataType: 'json',
            cache: false,
            success: function (data) {
                this.setState({ singledata: data });
                console.log(this.state.singledata);
                var populateEmp = this.state.singledata.map(function (Inventory) {
                    upInvid.value = theupInvid;
                    upInvname.value = Inventory.invname;
                    upInvdescrip.value = Inventory.invdescrip;
                    upInvunitprice.value = Inventory.invunitprice;
                    upInvindate.value = Inventory.invindate;
                    upInvoutdate.value = Inventory.invoutdate;
                    upInvquantityinstock.value = Inventory.invquantityinstock;
                    upInvsupplier.value = Inventory.invsupplier;
                });
            }.bind(this),
            error: function (xhr, status, err) {
                console.error(this.props.url, status, err.toString());
            }.bind(this)
        });
    },

    render: function () {

        return (

            <tr>
                <td>
                    {this.props.key}
                </td>
                <td>
                    {this.props.iname}
                </td>
                <td>
                    {this.props.idesc}
                </td>
                <td>
                    {this.props.iprice}
                </td>
                <td>
                    {this.props.iidate}
                </td>
                <td>
                    {this.props.iodate}
                </td>
                <td>
                    {this.props.iqst}
                </td>
                <td>
                    {this.props.isup}
                </td>
                <td>
                    <form onSubmit={this.updateRecord}>

                        <input type="submit" value="Edit" />
                    </form>
                </td>
            </tr>
        );
    }
});


ReactDOM.render(
    <InventoryUpdateBox />,
    document.getElementById('content')
);


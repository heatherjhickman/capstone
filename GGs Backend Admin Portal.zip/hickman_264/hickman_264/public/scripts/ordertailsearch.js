var OrderDetailSearchBox = React.createClass({

    getInitialState: function () {
        return { data: [] };
    },

    loadOrderDetailFromServer: function () {
        $.ajax({
            url: '/orderdetailsearch',
            data: {
                'orderdetailkey': orderdetailkey.value,
                'orderkey': orderkey.value,
                'mitemkey': mitemkey.value,
                'itemquantity': itemquantity.value,
            },
            dataType: 'json',
            cache: false,
            success: function (data) {
                this.setState({ data: data });
            }.bind(this),
            error: function (xhr, status, err) {
                console.error(this.props.url, status, err.toString());
            }.bind(this)
        });

    },
    componentDidMount: function () {
        this.loadOrderDetailFromServer();
    },

    render: function () {
        return (
            <div>
                <center>
                    <OrderDetailSearchForm onOrderDetailSubmit={this.loadOrderDetailFromServer} />
                    <br />
                    <table>
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Orderkey</th>
                                <th>Menu Item Key</th>
                                <th>Item Quantity</th>
                            </tr>
                        </thead>
                        <OrderDetailList data={this.state.data} />
                    </table>
                </center>
            </div>
        );
    }
});

var OrderDetailSearchForm = React.createClass({

    getInitialState: function () {
        return {
            orderdetailkey: "",
            orderkey: "",
            mitemkey: "",
            itemquantity: "",
        };
    },
    handleSubmit: function (e) {
        e.preventDefault();

        var orderdetailkey = this.state.orderdetailkey.trim();
        var orderkey = this.state.orderkey.trim();
        var mitemkey = this.state.mitemkey.trim();
        var itemquantity = this.state.itemquantity.trim();


        this.props.onOrderDetailSubmit({
            orderdetailkey: orderdetailkey,
            orderkey: orderkey,
            mitemkey: mitemkey,
            itemquantity: itemquantity
        });
    },

    handleChange: function (event) {
        this.setState({
            [event.target.id]: event.target.value
        });
    },

    render: function () {
        return (
            <center>
                <form className="OrderDetailSearchForm" onSubmit={this.handleSubmit}>
                    <h1>Search the Order Detail</h1>
                    <table border>
                        <tbody>
                            <tr>
                                <th>OrderDetail Item ID</th>
                                <td>
                                    <input name="orderdetailkey" id="orderdetailkey"
                                        value={this.state.orderdetailkey} onChange={this.handleChange} />
                                </td>
                            </tr>

                            <tr>
                                <th>Order Key</th>
                                <td>
                                    <input name="orderkey" id="orderkey"
                                        value={this.state.orderkey} onChange={this.handleChange} />
                                </td>
                            </tr>
                            <tr>
                                <th>Menu Item Key</th>
                                <td>
                                    <input name="mitemkey" id="mitemkey"
                                        value={this.state.mitemkey} onChange={this.handleChange} />
                                </td>
                            </tr>

                            <tr>
                                <th>Item Quantity</th>
                                <td>
                                    <input name="iteamquantity" id="itemquantity"
                                        value={this.state.itemquantity} onChange={this.handleChange} />
                                </td>
                            </tr>

                        </tbody>
                    </table> <br />
                    <input type="submit" name="thesubmit" value="Search" id="thesubmit" />

                </form>
            </center>
        );
    }
});


var OrderDetailList = React.createClass({
    render: function () {
        var OrderDetailNodes = this.props.data.map(function (OrderDetail) {
            return (
                <OrderDetail
                    key={OrderDetail.orderdetailkey}
                    ordkey={OrderDetail.orderkey}
                    mikey={OrderDetail.mitemkey}
                    iq={OrderDetail.itemquantity}
                >
                </OrderDetail>
            );

        });

        return (
            <tbody>
                {OrderDetailNodes}
            </tbody>
        );
    }
});



var OrderDetail = React.createClass({

    render: function () {
        return (

            <tr>

                <td>
                    {this.props.key}
                </td>
                <td>
                    {this.props.ordkey}
                </td>
                <td>
                    {this.props.mikey}
                </td>
                <td>
                    {this.props.iq}
                </td>
            </tr>
        );
    }
});


ReactDOM.render(
    <OrderDetailSearchBox />,
    document.getElementById('content')
);
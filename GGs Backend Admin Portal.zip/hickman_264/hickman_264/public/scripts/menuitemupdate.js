var MenuUpdateBox = React.createClass({
    getInitialState: function () {
        return { data: [] };
    },

    loadMenuFromServer: function () {
        $.ajax({
            url: '/menusearch',
            data: {
                'mitemkey': mitemkey.value,
                'mitemname': mitemname.value,
                'mitemdescrip': mitemdescrip.value,
                'mitemprice': mitemprice.value,
            },
            dataType: 'json',
            cache: false,
            success: function (data) {
                this.setState({ data: data });
            }.bind(this),
            error: function (xhr, status, err) {
                console.error(this.props.url, status, err.toString());
            }.bind(this)
        });

    },
    updateSingleMenuFromServer: function (Menu) {
        $.ajax({
            url: '/getsinglemenuitem',
            dataType: 'json',
            data: Menu,
            type: 'POST',
            cache: false,
            success: function (upsingledata) {
                this.setState({ upsingledata: upsingledata });
            }.bind(this),
            error: function (xhr, status, err) {
                console.error(this.props.url, status, err.toString());
            }.bind(this)
        });
        window.location.reload(true);
    },
    componentDidMount: function () {
        this.loadMenuFromServer();
    },

    render: function () {
        return (
            <div>
                <MenuUpdateForm onMenuSubmit={this.loadMenuFromServer} />
                <br />
                <div id="theresults">
                    <div id="theleft">
                        <table>
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Description</th>
                                    <th>Price</th>
                                </tr>
                            </thead>
                            <MenuList data={this.state.data} />
                        </table>
                    </div>
                    <div id="theright">
                        <MenuUpdateform onUpdateSubmit={this.updateSingleMenuFromServer} />
                    </div>
                </div>
            </div>
        );
    }
});

var MenuUpdateForm = React.createClass({
    getInitialState: function () {
        return {
            mitemkey: "",
            mitemname: "",
            mitemdescrip: "",
            mitemprice: "",
            data: []
        };
    },

    handleSubmit: function (e) {
        e.preventDefault();

        var mitemkey = this.state.mitemkey.trim();
        var mitemname = this.state.mitemname.trim();
        var mitemdescrip = this.state.mitemdescrip.trim();
        var mitemprice = this.state.mitemprice.trim();

        this.props.onMenuSubmit({
            mitemkey: mitemkey,
            mitemname: mitemname,
            mitemdescrip: mitemdescrip,
            mitemprice: mitemprice
        });
    },
    handleChange: function (event) {
        this.setState({
            [event.target.id]: event.target.value
        });
    },

    render: function () {
        return (
            <center>
                <form onSubmit={this.handleSubmit}>

                    <table border>
                        <tbody>
                            <tr>
                                <th>Menu Item ID</th>
                                <td>
                                    <input name="mitemkey" id="mitemkey"
                                        value={this.state.mitemkey} onChange={this.handleChange} />
                                </td>
                            </tr>

                            <tr>
                                <th>Menu Item Name</th>
                                <td>
                                    <input name="mitemname" id="mitemname"
                                        value={this.state.mitemname} onChange={this.handleChange} />
                                </td>
                            </tr>
                            <tr>
                                <th>Menu Item Description</th>
                                <td>
                                    <input name="mitemdescrip" id="mitemdescrip"
                                        value={this.state.mitemdescrip} onChange={this.handleChange} />
                                </td>
                            </tr>

                            <tr>
                                <th>Menu Item Unit Price</th>
                                <td>
                                    <input name="mitemprice" id="mitemprice"
                                        value={this.state.mitemprice} onChange={this.handleChange} />
                                </td>
                            </tr>
                        </tbody>
                    </table><br />
                    <input type="submit" name="thesubmit" value="Update" id="thesubmit" />
                </form>

                <div>
                    <br />
                    <form onSubmit={this.getInitialState}>
                        <input type="submit" value="Reset Forms" />
                    </form>
                </div>
            </center>
        );
    }
});

var MenuUpdateform = React.createClass({
    getInitialState: function () {
        return {
            upMitemid: "",
            upMitemname: "",
            upMitemdescrip: "",
            upMitemprice: "",
            updata: []
        };
    },

    handleUpSubmit: function (e) {
        e.preventDefault();

        var upMitemid = invid.value;
        var upMitemname = invname.value;
        var upMitemdescrip = invdescrip.value;
        var upMitemprice = invunitprice.value;

        this.props.onUpdateSubmit({
            upMitemid: upMitemid,
            upMitemname: upMitemname,
            upMitemdescrip: upMitemdescrip,
            upMitemprice: upMitemprice
        });

    },
    handleUpChange: function (event) {
        this.setState({
            [event.target.id]: event.target.value
        });
    },
    render: function () {

        return (
            <center>
                <div>
                    <div id="theform">
                        <form onSubmit={this.handleUpSubmit}>

                            <table>
                                <tbody>
                                    <tr>
                                        <th>Menu Item ID</th>
                                        <td>
                                            <input name="upMitemid" id="upMitemid"
                                                value={this.state.upMitemid} onChange={this.handleChange} />
                                        </td>
                                    </tr>

                                    <tr>
                                        <th>Menu Item Name</th>
                                        <td>
                                            <input name="upInvfname" id="upInvfname"
                                                value={this.state.upInvfname} onChange={this.handleChange} />
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>Menu Item Description</th>
                                        <td>
                                            <input name="upMitemdescrip" id="upMitemdescrip"
                                                value={this.state.upMitemdescrip} onChange={this.handleChange} />
                                        </td>
                                    </tr>

                                    <tr>
                                        <th>Menu Item Price</th>
                                        <td>
                                            <input name="upMitemprice" id="upMitemprice"
                                                value={this.state.upMitemprice} onChange={this.handleChange} />
                                        </td>
                                    </tr>
                                </tbody>
                            </table><br />
                            <input type="hidden" name="upMitemid" id="upMitemid" onChange={this.handleUpChange} />
                            <input type="submit" id="theupdate" value="Update" />
                        </form>
                    </div>
                </div></center>
        );
    }
});

var MenuList = React.createClass({
    render: function () {
        var MenuNodes = this.props.data.map(function (Menu) {
            return (
                <Menu
                    key={Menu.mitemkey}
                    mname={Menu.mitemname}
                    mdesc={Menu.mitemdescrip}
                    mprice={Menu.mitemprice}
                >
                </Menu>
            );
        });
        return (
            <tbody>
                {MenuNodes}
            </tbody>
        );
    }
});

var Menu = React.createClass({
    getInitialState: function () {
        return {
            upMitemid: "",
            singledata: []
        };
    },
    updateRecord: function (e) {
        e.preventDefault();
        var theupMitemid = this.props.cusid;

        this.loadSingleEmp(theupMitemid);
    },
    loadSingleEmp: function (theupMitemid) {
        $.ajax({
            url: '/getsingleMenu',
            data: {
                'upMitemid': theupMitemid
            },
            dataType: 'json',
            cache: false,
            success: function (data) {
                this.setState({ singledata: data });
                console.log(this.state.singledata);
                var populateEmp = this.state.singledata.map(function (Menu) {
                    upMitemid.value = theupMitemid;
                    upMitemname.value = Menu.invname;
                    upMitemdescrip.value = Menu.invdescrip;
                    upMitemprice.value = Menu.invunitprice;
                });
            }.bind(this),
            error: function (xhr, status, err) {
                console.error(this.props.url, status, err.toString());
            }.bind(this)
        });
    },

    render: function () {

        return (

            <tr>
                <td>
                    {this.props.key}
                </td>
                <td>
                    {this.props.mname}
                </td>
                <td>
                    {this.props.mdesc}
                </td>
                <td>
                    {this.props.mprice}
                </td>
                <td>
                    <form onSubmit={this.updateRecord}>

                        <input type="submit" value="Edit" />
                    </form>
                </td>
            </tr>
        );
    }
});


ReactDOM.render(
    <MenuUpdateBox />,
    document.getElementById('content')
);


var InventoryBox = React.createClass({
    handleInventorySubmit: function (inventory) {
        $.ajax({
            url: '/invinsert',
            dataType: 'json',
            type: 'POST',
            data: inventory,
            success: function (data) {

                this.setState({ data: data });
            }.bind(this),
            error: function (xhr, status, err) {
                console.log(this.props.url, status, err.toString());
            }.bind(this)
        });
    },

    render: function () {
        return (
            <div className="InventoryBox">
                <Inventoryform1 onInventorySubmit={this.handleInventorySubmit} />
            </div>
        );
    }
});

var Inventoryform1 = React.createClass({
    getInitialState: function () {
        return {

            invid: "",
            invname: "",
            invdescrip: "",
            invunitprice: "",
            invindate: "",
            invoutdate: "",
            invquantityinstock: "",
            invsupplier: "",

        };
    },

    handleSubmit: function (e) {
        e.preventDefault();

        var invid = this.state.invid.trim();
        var invname = this.state.invname.trim();
        var invdescrip = this.state.invdescrip.trim();
        var invunitprice = this.state.invunitprice.trim();
        var invindate = this.state.invindate.trim();
        var invoutdate = this.state.invoutdate.trim();
        var invquantityinstock = this.state.invquantityinstock.trim();
        var invsupplier = this.state.invsupplier.trim();

        this.props.onInventorySubmit({
            invid: invid,
            invname: invname,
            invdescrip: invdescrip,
            invunitprice: invunitprice,
            invindate: invindate,
            invoutdate: invoutdate,
            invquantityinstock: invquantityinstock,
            invsupplier: invsupplier
        });
        alert("1 record entered");
    },

    commonValidate: function () {
        return true;
    },

    validateNumber: function (value) {
        var regex = /^[0 - 9]?[0 - 9]?[0 - 9]?[0 - 9]?/;
        return regex.test(value);
    },

    /*validateDate: function (value) {
        var regex = (0[1 - 9] ? 1[012])[- /.](0[1-9]|[12][0-9]?3[01])[- /.](19|20)\d\d;
        return regex.test(value);
    },*/

    setValue: function (field, event) {
        var object = {};
        object[field] = event.target.value;
        this.setState(object);
    },

    render: function () {
        return (
            <center>
                <form className="Inventoryform1" onSubmit={this.handleSubmit}>

                    <table>
                        <tbody>

                            <tr>
                                <th>Inventory Item Name</th>
                                <td>
                                    <TextInput
                                        value={this.state.invname}
                                        uniqueName="invname"
                                        textArea={false}
                                        required={true}
                                        minCharacters={1}
                                        validate={this.commonValidate}
                                        onChange={this.setValue.bind(this, 'invname')}
                                        emptyMessage="Item name is required"
                                    />
                                </td>
                            </tr>

                            <tr>
                                <th>Inventory Item Description</th>
                                <td>
                                    <TextInput
                                        value={this.state.invdescrip}
                                        uniqueName="invdescrip"
                                        textArea={false}
                                        required={false}
                                        maxCharacters={255}
                                        validate={this.commonValidate}
                                        onChange={this.setValue.bind(this, 'invdescrip')}
                                    />
                                </td>
                            </tr>

                            <tr>
                                <th>Inventory Item Unit Price</th>
                                <td>
                                    <TextInput
                                        value={this.state.invunitprice}
                                        uniqueName="invunitprice"
                                        textArea={false}
                                        required={true}
                                        validate={this.validateNumber}
                                        onChange={this.setValue.bind(this, 'invunitprice')}
                                        emptyMessage="You must enter the unit price"
                                        errorMessage="Unit price must be in numbers"
                                    />
                                </td>

                            </tr>

                            <tr>
                                <th>Inventory Item In-Date</th>
                                <td>
                                    <TextInput
                                        value={this.state.invindate}
                                        uniqueName="invindate"
                                        textArea={false}
                                        required={true}
                                        validate={this.commonValidate}
                                        onChange={this.setValue.bind(this, 'invindate')}
                                        emptyMessage="You must enter the in-date"
                                        errorMessage="In-date must be in date format"
                                    />
                                </td>
                            </tr>

                            <tr>
                                <th>Inventory Item Out-Date</th>
                                <td>
                                    <TextInput
                                        value={this.state.invoutdate}
                                        uniqueName="invoutdate"
                                        textArea={false}
                                        required={true}
                                        validate={this.commonValidate}
                                        onChange={this.setValue.bind(this, 'invoutdate')}
                                        emptyMessage="You must enter the out-date"
                                        errorMessage="Out-date must be in date format"
                                    />
                                </td>
                            </tr>

                            <tr>
                                <th>Inventory Item Quantity in Stock</th>
                                <td>
                                    <TextInput
                                        value={this.state.invquantityinstock}
                                        uniqueName="invquantityinstock"
                                        textArea={false}
                                        required={true}
                                        validate={this.validateNumber}
                                        onChange={this.setValue.bind(this, 'invquantityinstock')}
                                        emptyMessage="You must enter the current item quantity"
                                        errorMessage="Quantity must be in numbers"
                                    />
                                </td>

                            </tr>

                            <tr>
                                <th>Inventory Item Supplier</th>
                                <td>
                                    <TextInput
                                        value={this.state.invsupplier}
                                        uniqueName="invsupplier"
                                        textArea={false}
                                        required={true}
                                        validate={this.commonValidate}
                                        onChange={this.setValue.bind(this, 'invsupplier')}
                                        emptyMessage="You must enter the item supplier"
                                    />
                                </td>
                            </tr>

                        </tbody>
                    </table><br />
                    <input type="submit" name="thesubmit" value="Insert" id="thesubmit" />
                </form>
            </center>
        );
    }
});


var InputError = React.createClass({
    getInitialState: function () {
        return {
            message: 'Input is invalid'
        };
    },
    render: function () {
        var errorClass = classNames(this.props.className, {
            'error_container': true,
            'visible': this.props.visible,
            'invisible': !this.props.visible
        });

        return (
            <div className={errorClass}>
                <td>{this.props.errorMessage}</td>
            </div>
        )
    }
});

var TextInput = React.createClass({
    getInitialState: function () {
        return {
            isEmpty: true,
            value: null,
            valid: false,
            errorMessage: "",
            errorVisible: false
        };
    },

    handleChange: function (event) {
        this.validation(event.target.value);
        if (this.props.onChange) {
            this.props.onChange(event);
        }
    },

    validation: function (value, valid) {
        if (typeof valid === 'undefined') {
            valid = true;
        }

        var message = "";
        var errorVisible = false;

        if (!valid) {
            message = this.props.errorMessage;
            valid = false;
            errorVisible = true;
        }
        else if (this.props.required && jQuery.isEmptyObject(value)) {
            message = this.props.emptyMessage;
            valid = false;
            errorVisible = true;
        }
        else if (value.length < this.props.minCharacters) {
            message = this.props.errorMessage;
            valid = false;
            errorVisible = true;
        }

        this.setState({
            value: value,
            isEmpty: jQuery.isEmptyObject(value),
            valid: valid,
            errorMessage: message,
            errorVisible: errorVisible
        });

    },

    handleBlur: function (event) {
        var valid = this.props.validate(event.target.value);
        this.validation(event.target.value, valid);
    },
    render: function () {
        if (this.props.textArea) {
            return (
                <div className={this.props.uniqueName}>
                    <textarea
                        placeholder={this.props.text}
                        className={'input input-' + this.props.uniqueName}
                        onChange={this.handleChange}
                        onBlur={this.handleBlur}
                        value={this.props.value} />

                    <InputError
                        visible={this.state.errorVisible}
                        errorMessage={this.state.errorMessage} />
                </div>
            );
        } else {
            return (
                <div className={this.props.uniqueName}>
                    <input
                        placeholder={this.props.text}
                        className={'input input-' + this.props.uniqueName}
                        onChange={this.handleChange}
                        onBlur={this.handleBlur}
                        value={this.props.value} />

                    <InputError
                        visible={this.state.errorVisible}
                        errorMessage={this.state.errorMessage} />
                </div>
            );
        }
    }
});
ReactDOM.render(
    <InventoryBox />,
    document.getElementById('content')
);
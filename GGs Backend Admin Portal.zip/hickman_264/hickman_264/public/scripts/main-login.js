var LoginBox = React.createClass({

    render: function () {

        return (
            <div className="LoginBox">
                <h1>GGs Administrative Portal Login</h1>
                <LoginForm onCustomerSubmit={this.handleLoginSubmit} />
            </div >
        );
    }

});

var LoginForm = React.createClass({

    getInitialState: function () {

        return {
            userid: "",
            password: "",
        };
    },

    handleSubmit: function (e) {
        e.preventDefault();
        var userid = this.state.userid.trim();
        var password = this.state.password.trim();
        if (userid.length < 8 || password.length < 8) {
            return;
        }
        else {
            this.setState({ userid: "", password: "" });
            window.location.href = "/main-home.html";
        }
    },

    commonValidate: function () {
        return true;
    },

    setValue: function (field, event) {
        var object = {};
        object[field] = event.target.value;
        this.setState(object);
    },


    render: function () {

        return (
            <center><form className="LoginForm" onSubmit={this.handleSubmit}>
                <table>
                    <h1>Please login</h1>
                    <tbody>
                        <tr>
                            <th>Username</th>
                            <td>
                                <TextInput
                                    value={this.state.username}
                                    uniqueName="username"
                                    textArea={false}
                                    required={true}
                                    minCharacters={8}
                                    validate={this.commonValidate}
                                    onChange={this.setValue.bind(this, 'username')}
                                    errorMessage="Username is invalid"
                                    emptyMessage="Username required" />
                            </td>
                        </tr>
                        <tr>
                            <th>Password</th>
                            <td>

                                <TextInput
                                    value={this.state.password}
                                    uniqueName="password"
                                    textArea={false}
                                    required={true}
                                    minCharacters={8}
                                    validate={this.commonValidate}
                                    onChange={this.setValue.bind(this, 'password')}
                                    errorMessage="Password does not match"
                                    emptyMessage="Password is required" />
                            </td>
                        </tr>
                    </tbody>
                </table>
                <br />
                <input type="submit" name="thesubmit" value="Login" id="thesubmit" />
            </form></center>
        );
    }

});





var InputError = React.createClass({
    getInitialState: function () {
        return {
            message: 'Input is invalid'
        };
    },
    render: function () {
        var errorClass = classNames(this.props.className, {
            'error_container': true,
            'visible': this.props.visible,
            'invisible': !this.props.visible
        });

        return (
            <div className={errorClass}>
                <td>{this.props.errorMessage}</td>
            </div>
        )
    }

});





var TextInput = React.createClass({
    getInitialState: function () {
        return {
            isEmpty: true,
            value: null,
            valid: false,
            errorMessage: "",
            errorVisible: false
        };
    },

    handleChange: function (event) {
        this.validation(event.target.value);

        if (this.props.onChange) {
            this.props.onChange(event);
        }
    },

    validation: function (value, valid) {
        if (typeof valid === 'undefined') {
            valid = true;
        }

        var message = "";
        var errorVisible = false;

        if (!valid) {

            message = this.props.errorMessage;
            valid = false;
            errorVisible = true;
        }
        else if (this.props.required && jQuery.isEmptyObject(value)) {

            message = this.props.emptyMessage;
            valid = false;
            errorVisible = true;
        }
        else if (value.length < this.props.minCharacters) {

            message = this.props.errorMessage;
            valid = false;
            errorVisible = true;
        }

        else if (value.length > this.props.maxCharacters) {

            message = this.props.errorMessage;
            valid = false;
            errorVisible = true;
        }

        this.setState({
            value: value,
            isEmpty: jQuery.isEmptyObject(value),
            valid: valid,
            errorMessage: message,
            errorVisible: errorVisible
        });

    },

    handleBlur: function (event) {

        var valid = this.props.validate(event.target.value);

        this.validation(event.target.value, valid);
    },
    render: function () {
        if (this.props.textArea) {
            return (
                <div className={this.props.uniqueName}>

                    <textarea
                        placeholder={this.props.text}
                        className={'input input-' + this.props.uniqueName}
                        onChange={this.handleChange}
                        onBlur={this.handleBlur}
                        value={this.props.value} />

                    <InputError
                        visible={this.state.errorVisible}
                        errorMessage={this.state.errorMessage} />
                </div>
            );
        } else {
            return (
                <div className={this.props.uniqueName}>
                    <input
                        placeholder={this.props.text}
                        className={'input input-' + this.props.uniqueName}
                        onChange={this.handleChange}
                        onBlur={this.handleBlur}
                        value={this.props.value} />

                    <InputError
                        visible={this.state.errorVisible}
                        errorMessage={this.state.errorMessage} />
                </div>
            );
        }
    }
});


ReactDOM.render(
    <LoginBox />,
    document.getElementById('content')
);
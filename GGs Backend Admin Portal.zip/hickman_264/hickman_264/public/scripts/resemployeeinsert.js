var EmployeeBox = React.createClass({
    handleEmployeeSubmit: function (resemployee) {
        $.ajax({
            url: '/employeeinsert',
            dataType: 'json',
            type: 'POST',
            data: resemployee,
            success: function (data) {

                this.setState({ data: data });
            }.bind(this),
            error: function (xhr, status, err) {
                console.log(this.props.url, status, err.toString());
            }.bind(this)
        });
    },

    render: function () {
        return (
            <div className="EmployeeBox">
                <EmployeeForm1 onEmployeeSubmit={this.handleEmployeeSubmit} />
            </div>
        );
    }
});

var EmployeeForm1 = React.createClass({
    getInitialState: function () {
        return {
            resempid: "",
            resempfname: "",
            resemplname: "",
            resempdob: "",
            resempemail: "",
            resempphone: "",
            resempadd1: "",
            resempadd2: "",
            resempcity: "",
            resempstate: "",
            resempzip: "",
            resemphiredate: "",
            resemptype: "",
            resempsalary: "",
            userid: "",
        };
    },

    handleSubmit: function (e) {
        e.preventDefault();

        var resempid = this.state.resempid.trim();
        var resempfname = this.state.resempfname.trim();
        var resemplname = this.state.resemplname.trim();
        var resempdob = this.state.resempdob.trim();
        var resempemail = this.state.resempemail.trim();
        var resempphone = this.state.resempphone.trim();
        var resempadd1 = this.state.resempadd1.trim();
        var resempadd2 = this.state.resempadd2.trim();
        var resempcity = this.state.resempcity.trim();
        var resempstate = this.state.resempstate.trim();
        var resempzip = this.state.resempzip.trim();
        var resemphiredate = this.state.resemphiredate.trim();
        var resemptype = this.state.resemptype.trim();
        var resempsalary = this.state.resempsalary.trim();
        var userid = this.state.userid.trim();

        console.log("E-good: " + this.validateEmail(resempemail))

        this.props.onEmployeeSubmit({
            resempid: resempid,
            resempfname: resempfname,
            resemplname: resemplname,
            resempdob: resempdob,
            resempemail: resempemail,
            resempphone: resempphone,
            resempadd1: resempadd1,
            resempadd2: resempadd2,
            resempcity: resempcity,
            resempstate: resempstate,
            resempzip: resempzip,
            resemphiredate: resemphiredate,
            resemptype: resemptype,
            resempsalary: resempsalary,
            userid: userid,
        });
        alert("1 record entered");

    },

    validateEmail: function (value) {
        var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        return re.test(value);
    },

    commonValidate: function () {
        return true;
    },

    validateNumber: function (value) {
        var re = /^[0 - 9]?[0 - 9]?[0 - 9]?[0 - 9]?/;
        return re.test(value);
    },

    setValue: function (field, event) {
        var object = {};
        object[field] = event.target.value;
        this.setState(object);
    },

    render: function () {
        return (
            <center>
                <form className="EmployeeForm1" onSubmit={this.handleSubmit}>

                    <table>
                        <tbody>

                            <tr>
                                <th>Employee First Name</th>
                                <td>
                                    <TextInput
                                        value={this.state.resempfname}
                                        uniqueName="resempfname"
                                        textArea={false}
                                        required={true}
                                        validate={this.commonValidate}
                                        onChange={this.setValue.bind(this, 'resempfname')}
                                        emptyMessage="Employee First Name Required"
                                    />
                                </td>
                            </tr>

                            <tr>
                                <th>Employee Last Name</th>
                                <td>
                                    <TextInput
                                        value={this.state.resemplname}
                                        uniqueName="resemplname"
                                        textArea={false}
                                        required={true}
                                        validate={this.commonValidate}
                                        onChange={this.setValue.bind(this, 'resemplname')}
                                        emptyMessage="Employee Last Name Required"
                                    />
                                </td>
                            </tr>

                            <tr>
                                <th>Employee Date of Birth</th>
                                <td>
                                    <TextInput
                                        value={this.state.resempdob}
                                        uniqueName="resempdob"
                                        textArea={false}
                                        required={true}
                                        onChange={this.setValue.bind(this, 'resempdob')}
                                        emptyMessage="Employee date of birth required"
                                    />
                                </td>

                            </tr>

                            <tr>
                                <th>Employee Email</th>
                                <td>
                                    <TextInput
                                        value={this.state.resempemail}
                                        uniqueName="resempemail"
                                        textArea={false}
                                        required={false}
                                        validate={this.validateEmail}
                                        onChange={this.setValue.bind(this, 'resempemail')}
                                        errorMessage="Employee Email Address Invalid"
                                    />
                                </td>
                            </tr>

                            <tr>
                                <th>Employee Phone Number</th>
                                <td>
                                    <TextInput
                                        value={this.state.resempphone}
                                        uniqueName="resempphone"
                                        textArea={false}
                                        required={true}
                                        validate={this.validateNumber}
                                        onChange={this.setValue.bind(this, 'resempphone')}
                                        errorMessage="Phone number must contain only numbers"
                                        emptyMessage="Employee phone number is required"
                                    />
                                </td>
                            </tr>

                            <tr>
                                <th>Employee Address 1</th>
                                <td>
                                    <TextInput
                                        value={this.state.resempadd1}
                                        uniqueName="resempadd1"
                                        textArea={false}
                                        required={true}
                                        validate={this.commonValidate}
                                        onChange={this.setValue.bind(this, 'resempadd1')}
                                        emptyMessage="Employee address is required"
                                    />
                                </td>
                            </tr>

                            <tr>
                                <th>Employee Address 2</th>
                                <td>
                                    <TextInput
                                        value={this.state.resempadd2}
                                        uniqueName="resempadd2"
                                        textArea={false}
                                        required={false}
                                        onChange={this.setValue.bind(this, 'resempadd2')}
                                    />
                                </td>
                            </tr>

                            <tr>
                                <th>Employee City</th>
                                <td>
                                    <TextInput
                                        value={this.state.resempcity}
                                        uniqueName="resempcity"
                                        textArea={false}
                                        required={true}
                                        validate={this.commonValidate}
                                        onChange={this.setValue.bind(this, 'resempcity')}
                                        emptyMessage="Employee city is required"
                                    />
                                </td>
                            </tr>

                            <tr>
                                <th>Employee State</th>
                                <td>
                                    <TextInput
                                        value={this.state.resempstate}
                                        uniqueName="resempstate"
                                        textArea={false}
                                        required={true}
                                        validate={this.commonValidate}
                                        onChange={this.setValue.bind(this, 'resempstate')}
                                        emptyMessage="Employee state is required"
                                    />
                                </td>
                            </tr>

                            <tr>
                                <th>Employee Zipcode</th>
                                <td>
                                    <TextInput
                                        value={this.state.resempzip}
                                        uniqueName="resempzip"
                                        textArea={false}
                                        required={true}
                                        validate={this.commonValidate}
                                        onChange={this.setValue.bind(this, 'resempzip')}
                                        emptyMessage="Employee zip is required"
                                    />
                                </td>
                            </tr>

                            <tr>
                                <th>Employee Hire Date</th>
                                <td>
                                    <TextInput
                                        value={this.state.resemphiredate}
                                        uniqueName="resemphiredate"
                                        textArea={false}
                                        required={true}
                                        validate={this.commonValidate}
                                        onChange={this.setValue.bind(this, 'resemphiredate')}
                                        emptyMessage="Employee hire date is required"
                                    />
                                </td>
                            </tr>

                            <tr>
                                <th>Employee Type</th>
                                <td>
                                    <TextInput
                                        value={this.state.resemptype}
                                        uniqueName="resemptype"
                                        textArea={false}
                                        required={true}
                                        validate={this.commonValidate}
                                        onChange={this.setValue.bind(this, 'resemptype')}
                                        emptyMessage="Employee type is required"
                                    />
                                </td>
                            </tr>

                            <tr>
                                <th>Employee Salary</th>
                                <td>
                                    <TextInput
                                        value={this.state.resempsalary}
                                        uniqueName="resempsalary"
                                        textArea={false}
                                        required={true}
                                        validate={this.validateNumber}
                                        onChange={this.setValue.bind(this, 'resempsalary')}
                                        emptyMessage="Employee salary is required"
                                        errorMessage="Salary must be in numbers"
                                    />
                                </td>
                            </tr>

                            <tr>
                                <th>Employee User ID</th>
                                <td>
                                    <TextInput
                                        value={this.state.userid}
                                        uniqueName="userid"
                                        textArea={false}
                                        required={true}
                                        validate={this.commonValidate}
                                        onChange={this.setValue.bind(this, 'userid')}
                                        emptyMessage="User ID is required"
                                    />
                                </td>
                            </tr>


                        </tbody>
                    </table><br />
                    <input type="submit" name="thesubmit" value="Insert" id="thesubmit" />
                </form>
            </center>
        );
    }
});


var InputError = React.createClass({
    getInitialState: function () {
        return {
            message: 'Input is invalid'
        };
    },
    render: function () {
        var errorClass = classNames(this.props.className, {
            'error_container': true,
            'visible': this.props.visible,
            'invisible': !this.props.visible
        });

        return (
            <div className={errorClass}>
                <td>{this.props.errorMessage}</td>
            </div>
        )
    }
});

var TextInput = React.createClass({
    getInitialState: function () {
        return {
            isEmpty: true,
            value: null,
            valid: false,
            errorMessage: "",
            errorVisible: false
        };
    },

    handleChange: function (event) {
        this.validation(event.target.value);
        if (this.props.onChange) {
            this.props.onChange(event);
        }
    },

    validation: function (value, valid) {
        if (typeof valid === 'undefined') {
            valid = true;
        }

        var message = "";
        var errorVisible = false;

        if (!valid) {
            message = this.props.errorMessage;
            valid = false;
            errorVisible = true;
        }
        else if (this.props.required && jQuery.isEmptyObject(value)) {
            message = this.props.emptyMessage;
            valid = false;
            errorVisible = true;
        }
        else if (value.length < this.props.minCharacters) {
            message = this.props.errorMessage;
            valid = false;
            errorVisible = true;
        }

        this.setState({
            value: value,
            isEmpty: jQuery.isEmptyObject(value),
            valid: valid,
            errorMessage: message,
            errorVisible: errorVisible
        });

    },

    handleBlur: function (event) {
        var valid = this.props.validate(event.target.value);
        this.validation(event.target.value, valid);
    },
    render: function () {
        if (this.props.textArea) {
            return (
                <div className={this.props.uniqueName}>
                    <textarea
                        placeholder={this.props.text}
                        className={'input input-' + this.props.uniqueName}
                        onChange={this.handleChange}
                        onBlur={this.handleBlur}
                        value={this.props.value} />

                    <InputError
                        visible={this.state.errorVisible}
                        errorMessage={this.state.errorMessage} />
                </div>
            );
        } else {
            return (
                <div className={this.props.uniqueName}>
                    <input
                        placeholder={this.props.text}
                        className={'input input-' + this.props.uniqueName}
                        onChange={this.handleChange}
                        onBlur={this.handleBlur}
                        value={this.props.value} />

                    <InputError
                        visible={this.state.errorVisible}
                        errorMessage={this.state.errorMessage} />
                </div>
            );
        }
    }
});
ReactDOM.render(
    <EmployeeBox />,
    document.getElementById('content')
);
var EmployeeUpdateBox = React.createClass({
    getInitialState: function () {
        return { data: [] };
    },

    loadEmployeeFromServer: function () {
        $.ajax({
            url: '/employeesearch',
            data: {
                'resempid': resempid.value,
                'resempfname': resempfname.value,
                'resemplname': resemplname.value,
                'resempdob': resempdob.value,
                'resempemail': resempemail.value,
                'resempphone': resempphone.value,
                'resempadd1': resempadd1.value,
                'resempadd2': resempadd2.value,
                'resempcity': resempcity.value,
                'resempstate': resempstate.value,
                'resempzip': resempzip.value,
                'resemphiredate': resemphiredate.value,
                'resemptype': resemptype.value,
                'resempsalary': resempsalary.value,
                'userid': userid.value,
            },
            dataType: 'json',
            cache: false,
            success: function (data) {
                this.setState({ data: data });
            }.bind(this),
            error: function (xhr, status, err) {
                console.error(this.props.url, status, err.toString());
            }.bind(this)
        });

    },
    updateSingleEmployeeFromServer: function (Employee) {
        $.ajax({
            url: '/getsingleemployee',
            dataType: 'json',
            data: Employee,
            type: 'POST',
            cache: false,
            success: function (upsingledata) {
                this.setState({ upsingledata: upsingledata });
            }.bind(this),
            error: function (xhr, status, err) {
                console.error(this.props.url, status, err.toString());
            }.bind(this)
        });
        window.location.reload(true);
    },
    componentDidMount: function () {
        this.loadEmployeeFromServer();
    },

    render: function () {
        return (
            <div>
                <EmployeeUpdateForm onEmployeeSubmit={this.loadEmployeeFromServer} />
                <br />
                <div id="theresults">
                    <div id="theleft">
                        <table>
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>First Name</th>
                                    <th>Last Name</th>
                                    <th>Date of Birth</th>
                                    <th>Email</th>
                                    <th>Phone</th>
                                    <th>Address 1</th>
                                    <th>Address 2</th>
                                    <th>City</th>
                                    <th>State</th>
                                    <th>Zipcode</th>
                                    <th>Hire Date</th>
                                    <th>Type</th>
                                    <th>Salary</th>
                                    <th>User ID</th>
                                </tr>
                            </thead>
                            <EmployeeList data={this.state.data} />
                        </table>
                    </div>
                    <div id="theright">
                        <EmployeeUpdateform onUpdateSubmit={this.updateSingleEmployeeFromServer} />
                    </div>
                </div>
            </div>
        );
    }
});

var EmployeeUpdateForm = React.createClass({
    getInitialState: function () {
        return {
            resempid: "",
            resempfname: "",
            resemplname: "",
            resempdob: "",
            resempemail: "",
            resempphone: "",
            resempadd1: "",
            resempadd2: "",
            resempcity: "",
            resempstate: "",
            resempzip: "",
            resemphiredate: "",
            resemptype: "",
            resempsalary: "",
            userid: "",
            data: []
        };
    },

    handleSubmit: function (e) {
        e.preventDefault();

        var resempid = this.state.resempid.trim();
        var resempfname = this.state.resempfname.trim();
        var resemplname = this.state.resemplname.trim();
        var resempdob = this.state.resempdob.trim();
        var resempemail = this.state.resempemail.trim();
        var resempphone = this.state.resempphone.trim();
        var resempadd1 = this.state.resempadd1.trim();
        var resempadd2 = this.state.resempadd2.trim();
        var resempcity = this.state.resempcity.trim();
        var resempstate = this.state.resempstate.trim();
        var resempzip = this.state.resempzip.trim();
        var resemphiredate = this.state.resemphiredate.trim();
        var resemptype = this.state.resemptype.trim();
        var resempsalary = this.state.resempsalary.trim();
        var userid = this.state.userid.trim();

        this.props.onEmployeeSubmit({
            resempid: resempid,
            resempfname: resempfname,
            resemplname: resemplname,
            resempdob: resempdob,
            resempemail: resempemail,
            resempphone: resempphone,
            resempadd1: resempadd1,
            resempadd2: resempadd2,
            resempcity: resempcity,
            resempstate: resempstate,
            resempzip: resempzip,
            resemphiredate: resemphiredate,
            resemptype: resemptype,
            resempsalary: resempsalary,
            userid: userid,
        });
    },
    handleChange: function (event) {
        this.setState({
            [event.target.id]: event.target.value
        });
    },

    render: function () {
        return (
            <center>
                <form className="EmployeeSearchForm" onSubmit={this.handleSubmit}>

                    <table bEmployee>
                        <tbody>
                            <tr>
                                <th>ID</th>
                                <td>
                                    <input name="resempid" id="resempid"
                                        value={this.state.resempid} onChange={this.handleChange} />
                                </td>
                            </tr>

                            <tr>
                                <th>First Name</th>
                                <td>
                                    <input name="resempfname" id="resemplname"
                                        value={this.state.resempfname} onChange={this.handleChange} />
                                </td>
                            </tr>
                            <tr>
                                <th>Last Name</th>
                                <td>
                                    <input name="resemplname" id="resemplname"
                                        value={this.state.resemplname} onChange={this.handleChange} />
                                </td>
                            </tr>

                            <tr>
                                <th>Date of Birth</th>
                                <td>
                                    <input name="resempdob" id="resempdob"
                                        value={this.state.resempdob} onChange={this.handleChange} />
                                </td>
                            </tr>

                            <tr>
                                <th>Email</th>
                                <td>
                                    <input name="resempemail" id="resempemail"
                                        value={this.state.resempemail} onChange={this.handleChange} />
                                </td>
                            </tr>

                            <tr>
                                <th>Phone</th>
                                <td>
                                    <input name="resempphone" id="resempphone"
                                        value={this.state.resempphone} onChange={this.handleChange} />
                                </td>
                            </tr>

                            <tr>
                                <th>Address 1</th>
                                <td>
                                    <input name="resempadd1" id="resempadd1"
                                        value={this.state.resempadd1} onChange={this.handleChange} />
                                </td>
                            </tr>
                            <tr>
                                <th>Address 2</th>
                                <td>
                                    <input name="resempadd2" id="resempadd2"
                                        value={this.state.resempadd2} onChange={this.handleChange} />
                                </td>
                            </tr>

                            <tr>
                                <th>City</th>
                                <td>
                                    <input name="resempcity" id="resempcity"
                                        value={this.state.resempcity} onChange={this.handleChange} />
                                </td>
                            </tr>

                            <tr>
                                <th>State</th>
                                <td>
                                    <input name="resempstate" id="resempstate"
                                        value={this.state.resempstate} onChange={this.handleChange} />
                                </td>
                            </tr>

                            <tr>
                                <th>Zipcode</th>
                                <td>
                                    <input name="resempzip" id="resempzip"
                                        value={this.state.resempzip} onChange={this.handleChange} />
                                </td>
                            </tr>

                            <tr>
                                <th>Hire Date</th>
                                <td>
                                    <input name="resemphiredate" id="resemphiredate"
                                        value={this.state.resemphiredate} onChange={this.handleChange} />
                                </td>
                            </tr>
                            <tr>
                                <th>Type</th>
                                <td>
                                    <input name="resemptype" id="resemptype"
                                        value={this.state.resemptype} onChange={this.handleChange} />
                                </td>
                            </tr>

                            <tr>
                                <th>Salary</th>
                                <td>
                                    <input name="resempsalary" id="resempsalary"
                                        value={this.state.resempsalary} onChange={this.handleChange} />
                                </td>
                            </tr>

                            <tr>
                                <th>User ID</th>
                                <td>
                                    <input name="userid" id="userid"
                                        value={this.state.userid} onChange={this.handleChange} />
                                </td>
                            </tr>
                        </tbody>
                    </table><br />
                    <input type="submit" name="thesubmit" value="Search" id="thesubmit" />
                </form>

                <div>
                    <br />
                    <form onSubmit={this.getInitialState}>
                        <input type="submit" value="Reset Forms" />
                    </form>
                </div>
            </center>
        );
    }
});

var EmployeeUpdateform = React.createClass({
    getInitialState: function () {
        return {
            upResempid: "",
            upResempfname: "",
            upResemplname: "",
            upResempdob: "",
            upResempemail: "",

            upResempphone: "",
            upResempadd1: "",
            upResempadd2: "",
            upResempcity: "",
            upResempstate: "",

            upResempzip: "",
            upResemphiredate: "",
            upResemptype: "",
            upResempsalary: "",
            upUserid: "",
            updata: []
        };
    },

    handleUpSubmit: function (e) {
        e.preventDefault();

        var upResempid = resempid.value;
        var upResempfname = resempfname.value;
        var upResemplname = resemplname.value;
        var upResempdob = resempdob.value;
        var upResempemail = resempemail.value;

        var upResempphone = resempphone.value;
        var upResempadd1 = resempadd1.value;
        var upResempadd2 = resempadd2.value;
        var upResempcity = resempcity.value;
        var upResempstate = resempstate.value;

        var upResempzip = resempzip.value;
        var upResemphiredate = resemphiredate.value;
        var upResemptype = resemptype.value;
        var upResempsalary = resempsalary.value;
        var upUserid = userid.value;

        this.props.onUpdateSubmit({
            upResempid: upResempid,
            upResempfname: upResempfname,
            upResemplname: upResemplname,
            upResempdob: upResempdob,
            upResempemail: upResempemail,

            upResempphone: upResempphone,
            upResempadd1: upResempadd1,
            upResempadd2: upResempadd2,
            upResempcity: upResempcity,
            upResempstate: upResempstate,

            upResempzip: upResempzip,
            upResemphiredate: upResemphiredate,
            upResemptype: upResemptype,
            upResempsalary: upResempsalary,
            upUserid: upUserid,
        });

    },
    handleUpChange: function (event) {
        this.setState({
            [event.target.id]: event.target.value
        });
    },
    render: function () {

        return (
            <center>
                <div>
                    <div id="theform">
                        <form onSubmit={this.handleUpSubmit}>

                            <table>
                                <tbody>
                                    <tr>
                                        <th>ID</th>
                                        <td>
                                            <input name="upResempid" id="upResempid"
                                                value={this.state.upResempid} onChange={this.handleChange} />
                                        </td>
                                    </tr>

                                    <tr>
                                        <th>First Name</th>
                                        <td>
                                            <input name="upResempfname" id="upResempfname"
                                                value={this.state.upResempfname} onChange={this.handleChange} />
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>Last Name</th>
                                        <td>
                                            <input name="upResemplname" id="upResemplname"
                                                value={this.state.upResemplname} onChange={this.handleChange} />
                                        </td>
                                    </tr>

                                    <tr>
                                        <th>Date of Birth</th>
                                        <td>
                                            <input name="upResempdob" id="upResempdob"
                                                value={this.state.upResempdob} onChange={this.handleChange} />
                                        </td>
                                    </tr>

                                    <tr>
                                        <th>Email</th>
                                        <td>
                                            <input name="upResempemail" id="upResempemail"
                                                value={this.state.upResempemail} onChange={this.handleChange} />
                                        </td>
                                    </tr>

                                    <tr>
                                        <th>Phone</th>
                                        <td>
                                            <input name="upResempphone" id="upResempphone"
                                                value={this.state.upResempphone} onChange={this.handleChange} />
                                        </td>
                                    </tr>

                                    <tr>
                                        <th>Address 1</th>
                                        <td>
                                            <input name="upResempadd1" id="upResempadd1"
                                                value={this.state.upResempadd1} onChange={this.handleChange} />
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>Address 2</th>
                                        <td>
                                            <input name="upResempadd2" id="upResempadd2"
                                                value={this.state.upResempadd2} onChange={this.handleChange} />
                                        </td>
                                    </tr>

                                    <tr>
                                        <th>City</th>
                                        <td>
                                            <input name="upResempcity" id="upResempcity"
                                                value={this.state.upResempcity} onChange={this.handleChange} />
                                        </td>
                                    </tr>

                                    <tr>
                                        <th>State</th>
                                        <td>
                                            <input name="upResempstate" id="upResempstate"
                                                value={this.state.upResempstate} onChange={this.handleChange} />
                                        </td>
                                    </tr>

                                    <tr>
                                        <th>Zipcode</th>
                                        <td>
                                            <input name="upResempzip" id="upResempzip"
                                                value={this.state.upResempzip} onChange={this.handleChange} />
                                        </td>
                                    </tr>

                                    <tr>
                                        <th>Hire Date</th>
                                        <td>
                                            <input name="upResemphiredate" id="upResemphiredate"
                                                value={this.state.upResemphiredate} onChange={this.handleChange} />
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>Type</th>
                                        <td>
                                            <input name="upResemptype" id="upResemptype"
                                                value={this.state.upResemptype} onChange={this.handleChange} />
                                        </td>
                                    </tr>

                                    <tr>
                                        <th>Salary</th>
                                        <td>
                                            <input name="upResempsalary" id="upResempsalary"
                                                value={this.state.upResempsalary} onChange={this.handleChange} />
                                        </td>
                                    </tr>

                                    <tr>
                                        <th>User ID</th>
                                        <td>
                                            <input name="upUserid" id="upUserid"
                                                value={this.state.upUserid} onChange={this.handleChange} />
                                        </td>
                                    </tr>
                                </tbody>
                            </table><br />
                            <input type="hidden" name="upResempid" id="upResempid" onChange={this.handleUpChange} />
                            <input type="submit" id="theupdate" value="Update" />
                        </form>
                    </div>
                </div></center>
        );
    }
});

var EmployeeList = React.createClass({
    render: function () {
        var EmployeeNodes = this.props.data.map(function (Employee) {
            return (
                <Employee
                    key={Employee.resempid}
                    efname={Employee.resempfname}
                    elname={Employee.resemplname}
                    edob={Employee.resempdob}
                    eemail={Employee.resempemail}
                    ephone={Employee.resempphone}
                    eadd1={Employee.resempadd1}
                    eadd2={Employee.resempadd2}
                    ecity={Employee.resempcity}
                    estate={Employee.resempstate}
                    ezip={Employee.resempzip}
                    ehd={Employee.resemphiredate}
                    etype={Employee.resemptype}
                    esal={Employee.resempsalary}
                    euid={Employee.userid}
                >
                </Employee>
            );
        });
        return (
            <tbody>
                {EmployeeNodes}
            </tbody>
        );
    }
});

var Employee = React.createClass({
    getInitialState: function () {
        return {
            upResempid: "",
            singledata: []
        };
    },
    updateRecord: function (e) {
        e.preventDefault();
        var theupResempid = this.props.resempid;

        this.loadSingleEmp(theupResempid);
    },
    loadSingleEmp: function (theupResempid) {
        $.ajax({
            url: '/getsingleemployee',
            data: {
                'upResempid': theupResempid
            },
            dataType: 'json',
            cache: false,
            success: function (data) {
                this.setState({ singledata: data });
                console.log(this.state.singledata);

                var populateEmp = this.state.singledata.map(function (Employee) {
                    upResempid.value = theupResempid;
                    upResempfname.value = Employee.resempfname;
                    upResemplname.value = Employee.resemplname;
                    upResempdob.value = Employee.resempdob;
                    upResempemail.value = Employee.resempemail;

                    upResempphone.value = Employee.resempphone;
                    upResempadd1.value = Employee.resempadd1;
                    upResempadd2.value = Employee.resempadd2;
                    upResempcity.value = Employee.resempcity;
                    upResempstate.value = Employee.resempstate;

                    upResempzip.value = Employee.resempzip;
                    upResemphiredate.value = Employee.resemphiredate;
                    upResemptype.value = Employee.resemptype;
                    upResempsalary.value = Employee.resempsalary;
                    upUserid.value = Employee.userid;
                });
            }.bind(this),
            error: function (xhr, status, err) {
                console.error(this.props.url, status, err.toString());
            }.bind(this)
        });
    },

    render: function () {

        return (

            <tr>
                <td>
                    {this.props.key}
                </td>
                <td>
                    {this.props.efname}
                </td>
                <td>
                    {this.props.elname}
                </td>
                <td>
                    {this.props.edob}
                </td>
                <td>
                    {this.props.eemail}
                </td>
                <td>
                    {this.props.ephone}
                </td>
                <td>
                    {this.props.eadd1}
                </td>
                <td>
                    {this.props.eadd2}
                </td>
                <td>
                    {this.props.ecity}
                </td>
                <td>
                    {this.props.estate}
                </td>
                <td>
                    {this.props.ezip}
                </td>
                <td>
                    {this.props.ehd}
                </td>
                <td>
                    {this.props.etype}
                </td>
                <td>
                    {this.props.esal}
                </td>
                <td>
                    {this.props.euid}
                </td>
                <td>
                    <form onSubmit={this.updateRecord}>

                        <input type="submit" value="Edit" />
                    </form>
                </td>
            </tr>
        );
    }
});


ReactDOM.render(
    <EmployeeUpdateBox />,
    document.getElementById('content')
);


var OrderBox = React.createClass({
    handleOrderSubmit: function (order) {
        $.ajax({
            url: '/orderinsert',
            dataType: 'json',
            type: 'POST',
            data: order,
            success: function (data) {

                this.setState({ data: data });
            }.bind(this),
            error: function (xhr, status, err) {
                console.log(this.props.url, status, err.toString());
            }.bind(this)
        });
    },

    render: function () {
        return (
            <div className="OrderBox">
                <OrderForm1 onOrderSubmit={this.handleOrderSubmit} />
            </div>
        );
    }
});

var OrderForm1 = React.createClass({
    getInitialState: function () {
        return {
            orderkey: "",
            cusid: "",
            resempid: "",
            orderdate: "",
            ordertime: "",
            orderstatus: "",
        };
    },

    handleSubmit: function (e) {
        e.preventDefault();

        var orderkey = this.state.orderkey.trim();
        var cusid = this.state.cusid.trim();
        var resempid = this.state.resempid.trim();
        var orderdate = this.state.orderdate.trim();
        var ordertime = this.state.ordertime.trim();
        var orderstatus = this.state.orderstatus.trim();

        this.props.onOrderSubmit({
            orderkey: orderkey,
            cusid: cusid,
            resempid: resempid,
            orderdate: orderdate,
            ordertime: ordertime,
            orderstatus: orderstatus
        });
        alert("1 record entered");

    },

    commonValidate: function () {
        return true;
    },

    setValue: function (field, event) {
        var object = {};
        object[field] = event.target.value;
        this.setState(object);
    },

    render: function () {
        return (
            <center>
                <form className="OrderForm1" onSubmit={this.handleSubmit}>

                    <table>
                        <tbody>

                            <tr>
                                <th>Customer ID</th>
                                <td>
                                    <TextInput
                                        value={this.state.cusid}
                                        uniqueName="cusid"
                                        textArea={false}
                                        required={true}
                                        validate={this.commonValidate}
                                        onChange={this.setValue.bind(this, 'cusid')}
                                        emptyMessage="Customer ID Required"
                                    />
                                </td>
                            </tr>

                            <tr>
                                <th>Employee ID</th>
                                <td>
                                    <TextInput
                                        value={this.state.resempid}
                                        uniqueName="resempid"
                                        textArea={false}
                                        required={true}
                                        validate={this.commonValidate}
                                        onChange={this.setValue.bind(this, 'resempid')}
                                        emptyMessage="Employee ID Required"
                                    />
                                </td>
                            </tr>

                            <tr>
                                <th>Order Date</th>
                                <td>
                                    <TextInput
                                        value={this.state.orderdate}
                                        uniqueName="orderdate"
                                        textArea={false}
                                        required={true}
                                        onChange={this.setValue.bind(this, 'orderdate')}
                                        emptyMessage="Order date is required"
                                    />
                                </td>

                            </tr>

                            <tr>
                                <th>Order Time</th>
                                <td>
                                    <TextInput
                                        value={this.state.ordertime}
                                        uniqueName="ordertime"
                                        textArea={false}
                                        required={true}
                                        validate={this.validateEmail}
                                        onChange={this.setValue.bind(this, 'ordertime')}
                                        emptyMessage="Order time is required"
                                    />
                                </td>
                            </tr>

                            <tr>
                                <th>Order Status</th>
                                <td>
                                    <TextInput
                                        value={this.state.orderstatus}
                                        uniqueName="orderstatus"
                                        textArea={false}
                                        required={true}
                                        onChange={this.setValue.bind(this, 'orderstatus')}
                                        emptyMessage="Order status is required"
                                    />
                                </td>
                            </tr>

                        </tbody>
                    </table><br />
                    <input type="submit" name="thesubmit" value="Insert" id="thesubmit" />
                </form>
            </center>
        );
    }
});


var InputError = React.createClass({
    getInitialState: function () {
        return {
            message: 'Input is invalid'
        };
    },
    render: function () {
        var errorClass = classNames(this.props.className, {
            'error_container': true,
            'visible': this.props.visible,
            'invisible': !this.props.visible
        });

        return (
            <div className={errorClass}>
                <td>{this.props.errorMessage}</td>
            </div>
        )
    }
});

var TextInput = React.createClass({
    getInitialState: function () {
        return {
            isEmpty: true,
            value: null,
            valid: false,
            errorMessage: "",
            errorVisible: false
        };
    },

    handleChange: function (event) {
        this.validation(event.target.value);
        if (this.props.onChange) {
            this.props.onChange(event);
        }
    },

    validation: function (value, valid) {
        if (typeof valid === 'undefined') {
            valid = true;
        }

        var message = "";
        var errorVisible = false;

        if (!valid) {
            message = this.props.errorMessage;
            valid = false;
            errorVisible = true;
        }
        else if (this.props.required && jQuery.isEmptyObject(value)) {
            message = this.props.emptyMessage;
            valid = false;
            errorVisible = true;
        }
        else if (value.length < this.props.minCharacters) {
            message = this.props.errorMessage;
            valid = false;
            errorVisible = true;
        }

        this.setState({
            value: value,
            isEmpty: jQuery.isEmptyObject(value),
            valid: valid,
            errorMessage: message,
            errorVisible: errorVisible
        });

    },

    handleBlur: function (event) {
        var valid = this.props.validate(event.target.value);
        this.validation(event.target.value, valid);
    },
    render: function () {
        if (this.props.textArea) {
            return (
                <div className={this.props.uniqueName}>
                    <textarea
                        placeholder={this.props.text}
                        className={'input input-' + this.props.uniqueName}
                        onChange={this.handleChange}
                        onBlur={this.handleBlur}
                        value={this.props.value} />

                    <InputError
                        visible={this.state.errorVisible}
                        errorMessage={this.state.errorMessage} />
                </div>
            );
        } else {
            return (
                <div className={this.props.uniqueName}>
                    <input
                        placeholder={this.props.text}
                        className={'input input-' + this.props.uniqueName}
                        onChange={this.handleChange}
                        onBlur={this.handleBlur}
                        value={this.props.value} />

                    <InputError
                        visible={this.state.errorVisible}
                        errorMessage={this.state.errorMessage} />
                </div>
            );
        }
    }
});
ReactDOM.render(
    <OrderBox />,
    document.getElementById('content')
);
var OrderUpdateBox = React.createClass({
    getInitialState: function () {
        return { data: [] };
    },

    loadOrderFromServer: function () {
        $.ajax({
            url: '/ordersearch',
            data: {
                'orderkey': orderkey.value,
                'cusid': cusid.value,
                'resempid': resempid.value,
                'orderdate': orderdate.value,
                'ordertime': ordertime.value,
                'orderstatus': orderstatus.value,
            },
            dataType: 'json',
            cache: false,
            success: function (data) {
                this.setState({ data: data });
            }.bind(this),
            error: function (xhr, status, err) {
                console.error(this.props.url, status, err.toString());
            }.bind(this)
        });

    },
    updateSingleOrderFromServer: function (Order) {
        $.ajax({
            url: '/getsingleorder',
            dataType: 'json',
            data: Order,
            type: 'POST',
            cache: false,
            success: function (upsingledata) {
                this.setState({ upsingledata: upsingledata });
            }.bind(this),
            error: function (xhr, status, err) {
                console.error(this.props.url, status, err.toString());
            }.bind(this)
        });
        window.location.reload(true);
    },
    componentDidMount: function () {
        this.loadOrderFromServer();
    },

    render: function () {
        return (
            <div>
                <OrderUpdateForm onOrderSubmit={this.loadOrderFromServer} />
                <br />
                <div id="theresults">
                    <div id="theleft">
                        <table>
                            <thead>
                                <tr>
                                    <th>Order ID</th>
                                    <th>Customer ID</th>
                                    <th>Employee ID</th>
                                    <th>Date</th>
                                    <th>Time</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <OrderList data={this.state.data} />
                        </table>
                    </div>
                    <div id="theright">
                        <OrderUpdateform onUpdateSubmit={this.updateSingleOrderFromServer} />
                    </div>
                </div>
            </div>
        );
    }
});

var OrderUpdateForm = React.createClass({
    getInitialState: function () {
        return {
            orderkey: "",
            cusid: "",
            resempid: "",
            orderdate: "",
            ordertime: "",
            orderstatus: "",
            data: []
        };
    },

    handleSubmit: function (e) {
        e.preventDefault();

        var orderkey = this.state.orderkey.trim();
        var cusid = this.state.cusid.trim();
        var resempid = this.state.resempid.trim();
        var orderdate = this.state.orderdate.trim();
        var ordertime = this.state.ordertime.trim();
        var orderstatus = this.state.orderstatus.trim();

        this.props.onOrderSubmit({
            orderkey: orderkey,
            cusid: cusid,
            resempid: resempid,
            orderdate: orderdate,
            ordertime: ordertime,
            orderstatus: orderstatus
        });
    },
    handleChange: function (event) {
        this.setState({
            [event.target.id]: event.target.value
        });
    },

    render: function () {
        return (
            <center>
                <form onSubmit={this.handleSubmit}>

                    <table border>
                        <tbody>
                            <tr>
                                <th>Order ID</th>
                                <td>
                                    <input name="orderkey" id="orderkey"
                                        value={this.state.orderkey} onChange={this.handleChange} />
                                </td>
                            </tr>

                            <tr>
                                <th>Customer ID</th>
                                <td>
                                    <input name="cusid" id="cusid"
                                        value={this.state.cusid} onChange={this.handleChange} />
                                </td>
                            </tr>
                            <tr>
                                <th>Employee ID</th>
                                <td>
                                    <input name="resempid" id="resempid"
                                        value={this.state.resempid} onChange={this.handleChange} />
                                </td>
                            </tr>

                            <tr>
                                <th>Order Date</th>
                                <td>
                                    <input name="orderdate" id="orderdate"
                                        value={this.state.orderdate} onChange={this.handleChange} />
                                </td>
                            </tr>

                            <tr>
                                <th>Order Time</th>
                                <td>
                                    <input name="ordertime" id="ordertime"
                                        value={this.state.ordertime} onChange={this.handleChange} />
                                </td>
                            </tr>

                            <tr>
                                <th>Order Status</th>
                                <td>
                                    <input name="orderstatus" id="orderstatus"
                                        value={this.state.orderstatus} onChange={this.handleChange} />
                                </td>
                            </tr>
                        </tbody>
                    </table><br />
                    <input type="submit" name="thesubmit" value="Search" id="thesubmit" />
                </form>

                <div>
                    <br />
                    <form onSubmit={this.getInitialState}>
                        <input type="submit" value="Reset Forms" />
                    </form>
                </div>
            </center>
        );
    }
});

var OrderUpdateform = React.createClass({
    getInitialState: function () {
        return {
            upOrderkey: "",
            upCusid: "",
            upResempid: "",
            upOrderdate: "",
            upOrdertime: "",
            upOrderstatus: "",
            updata: []
        };
    },

    handleUpSubmit: function (e) {
        e.preventDefault();

        var upOrderkey = orderkey.value;
        var upCusid = cusid.value;
        var upResempid = resempid.value;
        var upOrderdate = orderdate.value;
        var upOrdertime = ordertime.value;
        var upOrderstatus = orderstatus.value;

        this.props.onUpdateSubmit({
            upOrderkey: upOrderkey,
            upCusid: upCusid,
            upResempid: upResempid,
            upOrderdate: upOrderdate,
            upOrdertime: upOrdertime,
            upOrderstatus: upOrderstatus
        });

    },
    handleUpChange: function (event) {
        this.setState({
            [event.target.id]: event.target.value
        });
    },
    render: function () {

        return (
            <center>
                <div>
                    <div id="theform">
                        <form onSubmit={this.handleUpSubmit}>

                            <table>
                                <tbody>
                                    <tr>
                                    <th>Order ID</th>
                                    <td>
                                            <input name="upOrderkey" id="upOrderkey"
                                                value={this.state.upOrderkey} onChange={this.handleChange} />
                                    </td>
                            </tr>

                                <tr>
                                    <th>Customer ID</th>
                                    <td>
                                            <input name="upCusid" id="upCusid"
                                                value={this.state.upCusid} onChange={this.handleChange} />
                                    </td>
                                </tr>
                                <tr>
                                    <th>Employee ID</th>
                                    <td>
                                            <input name="upResempid" id="upResempid"
                                                value={this.state.upResempid} onChange={this.handleChange} />
                                    </td>
                                </tr>

                                <tr>
                                    <th>Order Date</th>
                                    <td>
                                            <input name="upOrderdate" id="upOrderdate"
                                                value={this.state.upOrderdate} onChange={this.handleChange} />
                                    </td>
                                </tr>

                                <tr>
                                    <th>Order Time</th>
                                    <td>
                                            <input name="upOrdertime" id="upOrdertime"
                                                value={this.state.upOrdertime} onChange={this.handleChange} />
                                    </td>
                                </tr>

                                <tr>
                                    <th>Order Status</th>
                                    <td>
                                        <input name="upOrderstatus" id="upOrderstatus"
                                                value={this.state.upOrderstatus} onChange={this.handleChange} />
                                    </td>
                                </tr>
                                </tbody>
                            </table><br />
                            <input type="hidden" name="upOrderkey" id="upOrderkey" onChange={this.handleUpChange} />
                            <input type="submit" id="theupdate" value="Update" />
                        </form>
                    </div>
                </div></center>
        );
    }
});

var OrderList = React.createClass({
    render: function () {
        var OrderNodes = this.props.data.map(function (Order) {
            return (
                <Order
                    key={Order.orderkey}
                    cid={Order.cusid}
                    eid={Order.resempid}
                    od={Order.orderdate}
                    ot={Order.ordertime}
                    os={Order.orderstatus}
                >
                </Order>
            );
        });
        return (
            <tbody>
                {OrderNodes}
            </tbody>
        );
    }
});

var Order = React.createClass({
    getInitialState: function () {
        return {
            upOrderkey: "",
            singledata: []
        };
    },
    updateRecord: function (e) {
        e.preventDefault();
        var theupOrderkey = this.props.orderkey;

        this.loadSingleEmp(theupOrderkey);
    },
    loadSingleEmp: function (theupOrderkey) {
        $.ajax({
            url: '/getsingleorder',
            data: {
                'upOrderkey': theupOrderkey
            },
            dataType: 'json',
            cache: false,
            success: function (data) {
                this.setState({ singledata: data });
                console.log(this.state.singledata);
                var populateEmp = this.state.singledata.map(function (Order) {
                    upOrderkey.value = theupOrderkey;
                    upCusid.value = Order.cusid;
                    upResempid.value = Order.resempid;
                    upOrderdate.value = Order.orderdate;
                    upOrdertime.value = Order.ordertime;
                    upOrderstatus.value = Order.orderstatus;
                });
            }.bind(this),
            error: function (xhr, status, err) {
                console.error(this.props.url, status, err.toString());
            }.bind(this)
        });
    },

    render: function () {

        return (

            <tr>
                <td>
                    {this.props.key}
                </td>
                <td>
                    {this.props.cid}
                </td>
                <td>
                    {this.props.eid}
                </td>
                <td>
                    {this.props.od}
                </td>
                <td>
                    {this.props.ot}
                </td>
                <td>
                    {this.props.os}
                </td>
                <td>
                    <form onSubmit={this.updateRecord}>

                        <input type="submit" value="Edit" />
                    </form>
                </td>
            </tr>
        );
    }
});


ReactDOM.render(
    <OrderUpdateBox />,
    document.getElementById('content')
);


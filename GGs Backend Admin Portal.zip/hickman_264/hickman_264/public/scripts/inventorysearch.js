var InventorySearchBox = React.createClass({

    getInitialState: function () {
        return { data: [] };
    },

    loadInventoryFromServer: function () {
        $.ajax({
            url: '/invsearch',
            data: {
                'invid': invid.value,
                'invname': invname.value,
                'invdescrip': invdescrip.value,
                'invunitprice': invunitprice.value,
                'invindate': invindate.value,
                'invoutdate': invoutdate.value,
                'invquantityinstock': invquantityinstock.value,
                'invsupplier': invsupplier.value,
            },
            dataType: 'json',
            cache: false,
            success: function (data) {
                this.setState({ data: data });
            }.bind(this),
            error: function (xhr, status, err) {
                console.error(this.props.url, status, err.toString());
            }.bind(this)
        });

    },
    componentDidMount: function () {
        this.loadInventoryFromServer();
    },

    render: function () {
        return (
            <div>
                <center>
                    <InventorySearchForm onInventorySubmit={this.loadInventoryFromServer} />
                    <br />
                    <table>
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Description</th>
                                <th>Price</th>
                                <th>In-Date</th>
                                <th>Out-Date</th>
                                <th>Quantity</th>
                                <th>Supplier</th>
                            </tr>
                        </thead>
                        <InventoryList data={this.state.data} />
                    </table>
                </center>
            </div>
        );
    }
});

var InventorySearchForm = React.createClass({

    getInitialState: function () {
        return {
            invid: "",
            invname: "",
            invdescrip: "",
            invunitprice: "",
            invindate: "",
            invoutdate: "",
            invquantityinstock: "",
            invsupplier: "",
        };
    },

    handleSubmit: function (e) {
        e.preventDefault();

        var invid = this.state.invid.trim();
        var invname = this.state.invname.trim();
        var invdescrip = this.state.invdescrip.trim();
        var invunitprice = this.state.invunitprice.trim();
        var invindate = this.state.invindate.trim();
        var invoutdate = this.state.invoutdate.trim();
        var invquantityinstock = this.state.invquantityinstock.trim();
        var invsupplier = this.state.invsupplier.trim();


        this.props.onInventorySubmit({
            invid: invid,
            invname: invname,
            invdescrip: invdescrip,
            invunitprice: invunitprice,
            invindate: invindate,
            invoutdate: invoutdate,
            invquantityinstock: invquantityinstock,
            invsupplier: invsupplier
        });
    },

    handleChange: function (event) {
        this.setState({
            [event.target.id]: event.target.value
        });
    },

    render: function () {
        return (
            <center>
                <form className="InventorySearchForm" onSubmit={this.handleSubmit}>
                    <h1>Search Inventory</h1>
                    <table border>
                        <tbody>
                            <tr>
                                <th>Inventory ID</th>
                                <td>
                                    <input name="invid" id="invid"
                                        value={this.state.invid} onChange={this.handleChange} />
                                </td>
                            </tr>

                            <tr>
                                <th>Inventory Name</th>
                                <td>
                                    <input name="invname" id="invname"
                                        value={this.state.invname} onChange={this.handleChange} />
                                </td>
                            </tr>
                            <tr>
                                <th>Inventory Description</th>
                                <td>
                                    <input name="invdescrip" id="invdescrip"
                                        value={this.state.invdescrip} onChange={this.handleChange} />
                                </td>
                            </tr>

                            <tr>
                                <th>Inventory Unit Price</th>
                                <td>
                                    <input name="invunitprice" id="invunitprice"
                                        value={this.state.invunitprice} onChange={this.handleChange} />
                                </td>
                            </tr>

                            <tr>
                                <th>Inventory In-Date</th>
                                <td>
                                    <input name="invindate" id="invindate"
                                        value={this.state.invindate} onChange={this.handleChange} />
                                </td>
                            </tr>

                            <tr>
                                <th>Inventory Out-Date</th>
                                <td>
                                    <input name="invoutdate" id="invoutdate"
                                        value={this.state.invoutdate} onChange={this.handleChange} />
                                </td>
                            </tr>

                            <tr>
                                <th>Inventory Quantity</th>
                                <td>
                                    <input name="invquantityinstock" id="invquantityinstock"
                                        value={this.state.invquantityinstock} onChange={this.handleChange} />
                                </td>
                            </tr>

                            <tr>
                                <th>Inventory Supplier</th>
                                <td>
                                    <input name="invsupplier" id="invsupplier"
                                        value={this.state.invsupplier} onChange={this.handleChange} />
                                </td>
                            </tr>

                        </tbody>
                    </table> <br />
                    <input type="submit" name="thesubmit" value="Search" id="thesubmit" />

                </form>
            </center>
        );
    }
});


var InventoryList = React.createClass({
    render: function () {
        var InventoryNodes = this.props.data.map(function (inventory) {
            return (
                <Inventory
                    key={inventory.invid}
                    iname={inventory.invname}
                    idesc={inventory.invdescrip}
                    iprice={inventory.invunitprice}
                    iidate={inventory.invindate}
                    iodate={inventory.invoutdate}
                    iqst={inventory.invquantityinstock}
                    isup={inventory.invsupplier}

                >
                </Inventory>
            );

        });

        return (
            <tbody>
                {InventoryNodes}
            </tbody>
        );
    }
});



var Inventory = React.createClass({

    render: function () {
        return (

            <tr>

                <td>
                    {this.props.key}
                </td>
                <td>
                    {this.props.iname}
                </td>
                <td>
                    {this.props.idesc}
                </td>
                <td>
                    {this.props.iprice}
                </td>
                <td>
                    {this.props.iidate}
                </td>
                <td>
                    {this.props.iodate}
                </td>
                <td>
                    {this.props.iqst}
                </td>
                <td>
                    {this.props.isup}
                </td>
            </tr>
        );
    }
});


ReactDOM.render(
    <InventorySearchBox />,
    document.getElementById('content')
);
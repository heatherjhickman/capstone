var CustomerBox = React.createClass({
    handleCustomerSubmit: function (customer) {
        $.ajax({
            url: '/customerinsert',
            dataType: 'json',
            type: 'POST',
            data: customer,
            success: function (data) {

                this.setState({ data: data });
            }.bind(this),
            error: function (xhr, status, err) {
                console.log(this.props.url, status, err.toString());
            }.bind(this)
        });
    },

    render: function () {
        return (
            <div className="CustomerBox">
                <CustomerForm1 onCustomerSubmit={this.handleCustomerSubmit} />
            </div>
        );
    }
});

var CustomerForm1 = React.createClass({
    getInitialState: function () {
        return {
            cusid: "",
            cusfname: "",
            cuslname: "",
            cusphone: "",
            cusemail: "",

        };
    },

    handleSubmit: function (e) {
        e.preventDefault();

        var cusid = this.state.cusid.trim();
        var cusfname = this.state.cusfname.trim();
        var cuslname = this.state.cuslname.trim();
        var cusphone = this.state.cusphone.trim();
        var cusemail = this.state.cusemail.trim();

        console.log("E-good: " + this.validateEmail(cusemail))

        this.props.onCustomerSubmit({
            cusid: cusid,
            cusfname: cusfname,
            cuslname: cuslname,
            cusphone: cusphone,
            cusemail: cusemail
        });
        alert("1 record entered");

    },

    validateEmail: function (value) {
        var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        return re.test(value);
    },

    commonValidate: function () {
        return true;
    },

    setValue: function (field, event) {
        var object = {};
        object[field] = event.target.value;
        this.setState(object);
    },

    render: function () {
        return (
            <center>
                <form className="CustomerForm1" onSubmit={this.handleSubmit}>

                    <table>
                        <tbody>

                            <tr>
                                <th>Customer First Name</th>
                                <td>
                                    <TextInput
                                        value={this.state.cusfname}
                                        uniqueName="cusfname"
                                        textArea={false}
                                        required={true}
                                        minCharacters={1}
                                        validate={this.commonValidate}
                                        onChange={this.setValue.bind(this, 'cusfname')}
                                        errorMessage="Customer First Name Invalid"
                                        emptyMessage="Customer First Name Required"
                                    />
                                </td>
                            </tr>

                            <tr>
                                <th>Customer Last Name</th>
                                <td>
                                    <TextInput
                                        value={this.state.cuslname}
                                        uniqueName="cuslname"
                                        textArea={false}
                                        required={true}
                                        minCharacters={1}
                                        validate={this.commonValidate}
                                        onChange={this.setValue.bind(this, 'cuslname')}
                                        errorMessage="Customer Last Name Invalid"
                                        emptyMessage="Customer Last Name Required"
                                    />
                                </td>
                            </tr>

                            <tr>
                                <th>Customer Phone Number</th>
                                <td>
                                    <TextInput
                                        value={this.state.cusphone}
                                        uniqueName="cusphone"
                                        textArea={false}
                                        required={true}
                                        minCharacters={7}
                                        minCharacters={12}
                                        onChange={this.setValue.bind(this, 'cusphone')}
                                        emptyMessage="You must enter customer phone"
                                    />
                                </td>

                            </tr>

                            <tr>
                                <th>Customer Email</th>
                                <td>
                                    <TextInput
                                        value={this.state.cusemail}
                                        uniqueName="cusemail"
                                        textArea={false}
                                        required={false}
                                        validate={this.validateEmail}
                                        onChange={this.setValue.bind(this, 'cusemail')}
                                        errorMessage="Customer Email Address Invalid"
                                    />
                                </td>
                            </tr>

                        </tbody>
                    </table><br />
                    <input type="submit" name="thesubmit" value="Insert" id="thesubmit"/>
                </form>
            </center>
        );
    }
});


var InputError = React.createClass({
    getInitialState: function () {
        return {
            message: 'Input is invalid'
        };
    },
    render: function () {
        var errorClass = classNames(this.props.className, {
            'error_container': true,
            'visible': this.props.visible,
            'invisible': !this.props.visible
        });

        return (
            <div className={errorClass}>
                <td>{this.props.errorMessage}</td>
            </div>
        )
    }
});

var TextInput = React.createClass({
    getInitialState: function () {
        return {
            isEmpty: true,
            value: null,
            valid: false,
            errorMessage: "",
            errorVisible: false
        };
    },

    handleChange: function (event) {
        this.validation(event.target.value);
        if (this.props.onChange) {
            this.props.onChange(event);
        }
    },

    validation: function (value, valid) {
        if (typeof valid === 'undefined') {
            valid = true;
        }

        var message = "";
        var errorVisible = false;

        if (!valid) {
            message = this.props.errorMessage;
            valid = false;
            errorVisible = true;
        }
        else if (this.props.required && jQuery.isEmptyObject(value)) {
            message = this.props.emptyMessage;
            valid = false;
            errorVisible = true;
        }
        else if (value.length < this.props.minCharacters) {
            message = this.props.errorMessage;
            valid = false;
            errorVisible = true;
        }

        this.setState({
            value: value,
            isEmpty: jQuery.isEmptyObject(value),
            valid: valid,
            errorMessage: message,
            errorVisible: errorVisible
        });

    },

    handleBlur: function (event) {
        var valid = this.props.validate(event.target.value);
        this.validation(event.target.value, valid);
    },
    render: function () {
        if (this.props.textArea) {
            return (
                <div className={this.props.uniqueName}>
                    <textarea
                        placeholder={this.props.text}
                        className={'input input-' + this.props.uniqueName}
                        onChange={this.handleChange}
                        onBlur={this.handleBlur}
                        value={this.props.value} />

                    <InputError
                        visible={this.state.errorVisible}
                        errorMessage={this.state.errorMessage} />
                </div>
            );
        } else {
            return (
                <div className={this.props.uniqueName}>
                    <input
                        placeholder={this.props.text}
                        className={'input input-' + this.props.uniqueName}
                        onChange={this.handleChange}
                        onBlur={this.handleBlur}
                        value={this.props.value} />

                    <InputError
                        visible={this.state.errorVisible}
                        errorMessage={this.state.errorMessage} />
                </div>
            );
        }
    }
});
ReactDOM.render(
    <CustomerBox />,
    document.getElementById('content')
);
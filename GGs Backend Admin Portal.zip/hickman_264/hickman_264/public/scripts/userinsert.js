var UserBox = React.createClass({
    handleUserSubmit: function (users) {
        $.ajax({
            url: '/userinsert',
            dataType: 'json',
            type: 'POST',
            data: users,
            success: function (data) {

                this.setState({ data: data });
            }.bind(this),
            error: function (xhr, status, err) {
                console.log(this.props.url, status, err.toString());
            }.bind(this)
        });
    },

    render: function () {
        return (
            <div className="UserBox">
                <UserForm1 onUserSubmit={this.handleUserSubmit} />
            </div>
        );
    }
});

var UserForm1 = React.createClass({
    getInitialState: function () {
        return {

            userid: "",
            employeeid: "",
            username: "",
            password: "",
            seclvl: "",
        };
    },

    handleSubmit: function (e) {
        e.preventDefault();

        var userid = this.state.userid.trim();
        var employeeid = this.state.employeeid.trim();
        var username = this.state.username.trim();
        var password = this.state.password.trim();
        var seclvl = this.state.seclvl.trim();

        this.props.onUserSubmit({
            userid: userid,
            employeeid: employeeid,
            username: username,
            password: password,
            seclvl: seclvl,
        });
        alert("1 record entered");
    },

    validateNumber: function (value) {
        var regex = /^[0 - 9]?[0 - 9]?[0 - 9]?[0 - 9]?/;
        return regex.test(value);
    },

    commonValidate: function () {
        return true;
    },

    setValue: function (field, event) {
        var object = {};
        object[field] = event.target.value;
        this.setState(object);
    },

    render: function () {
        return (
            <center>
                <form className="UserForm1" onSubmit={this.handleSubmit}>

                    <table>
                        <tbody>

                            <tr>
                                <th>Employee ID</th>
                                <td>
                                    <TextInput
                                        value={this.state.employeeid}
                                        uniqueName="employeeid"
                                        textArea={false}
                                        required={true}
                                        validate={this.commonValidate}
                                        onChange={this.setValue.bind(this, 'employeeid')}
                                        emptyMessage="Employee ID is required"
                                    />
                                </td>
                            </tr>

                            <tr>
                                <th>Username</th>
                                <td>
                                    <TextInput
                                        value={this.state.username}
                                        uniqueName="username"
                                        textArea={false}
                                        required={true}
                                        validate={this.commonValidate}
                                        onChange={this.setValue.bind(this, 'username')}
                                        emptyMessage="Username is required"
                                    />
                                </td>
                            </tr>

                            <tr>
                                <th>Password</th>
                                <td>
                                    <TextInput
                                        value={this.state.password}
                                        uniqueName="password"
                                        textArea={false}
                                        required={true}
                                        minCharacters={8}
                                        minCharacters={20}
                                        onChange={this.setValue.bind(this, 'password')}
                                        errorMessage="Password must be at least 8 characters and no more than 20"
                                        emptyMessage="Password is required"
                                    />
                                </td>
                            </tr>

                            <tr>
                                <th>Security Level</th>
                                <td>
                                    <TextInput
                                        value={this.state.seclvl}
                                        uniqueName="seclvl"
                                        textArea={false}
                                        required={true}
                                        validate={this.validateNumber}
                                        onChange={this.setValue.bind(this, 'seclvl')}
                                        errorMessage="Security level must be a number between 1-4"
                                        emptyMessage="Security level must be entered"
                                    />
                                </td>
                            </tr>

                        </tbody>
                    </table><br />
                    <input type="submit" name="thesubmit" value="Insert" id="thesubmit" />
                </form>
            </center>
        );
    }
});


var InputError = React.createClass({
    getInitialState: function () {
        return {
            message: 'Input is invalid'
        };
    },
    render: function () {
        var errorClass = classNames(this.props.className, {
            'error_container': true,
            'visible': this.props.visible,
            'invisible': !this.props.visible
        });

        return (
            <div className={errorClass}>
                <td>{this.props.errorMessage}</td>
            </div>
        )
    }
});

var TextInput = React.createClass({
    getInitialState: function () {
        return {
            isEmpty: true,
            value: null,
            valid: false,
            errorMessage: "",
            errorVisible: false
        };
    },

    handleChange: function (event) {
        this.validation(event.target.value);
        if (this.props.onChange) {
            this.props.onChange(event);
        }
    },

    validation: function (value, valid) {
        if (typeof valid === 'undefined') {
            valid = true;
        }

        var message = "";
        var errorVisible = false;

        if (!valid) {
            message = this.props.errorMessage;
            valid = false;
            errorVisible = true;
        }
        else if (this.props.required && jQuery.isEmptyObject(value)) {
            message = this.props.emptyMessage;
            valid = false;
            errorVisible = true;
        }
        else if (value.length < this.props.minCharacters) {
            message = this.props.errorMessage;
            valid = false;
            errorVisible = true;
        }

        this.setState({
            value: value,
            isEmpty: jQuery.isEmptyObject(value),
            valid: valid,
            errorMessage: message,
            errorVisible: errorVisible
        });

    },

    handleBlur: function (event) {
        var valid = this.props.validate(event.target.value);
        this.validation(event.target.value, valid);
    },
    render: function () {
        if (this.props.textArea) {
            return (
                <div className={this.props.uniqueName}>
                    <textarea
                        placeholder={this.props.text}
                        className={'input input-' + this.props.uniqueName}
                        onChange={this.handleChange}
                        onBlur={this.handleBlur}
                        value={this.props.value} />

                    <InputError
                        visible={this.state.errorVisible}
                        errorMessage={this.state.errorMessage} />
                </div>
            );
        } else {
            return (
                <div className={this.props.uniqueName}>
                    <input
                        placeholder={this.props.text}
                        className={'input input-' + this.props.uniqueName}
                        onChange={this.handleChange}
                        onBlur={this.handleBlur}
                        value={this.props.value} />

                    <InputError
                        visible={this.state.errorVisible}
                        errorMessage={this.state.errorMessage} />
                </div>
            );
        }
    }
});
ReactDOM.render(
    <UserBox />,
    document.getElementById('content')
);
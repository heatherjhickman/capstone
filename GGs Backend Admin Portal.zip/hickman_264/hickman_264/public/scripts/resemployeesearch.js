var EmployeeSearchBox = React.createClass({

    getInitialState: function () {
        return { data: [] };
    },

    loadEmployeeFromServer: function () {
        $.ajax({
            url: '/employeesearch',
            data: {
                'resempid': resempid.value,
                'resempfname': resempfname.value,
                'resemplname': resemplname.value,
                'resempdob': resempdob.value,
                'resempemail': resempemail.value,
                'resempphone': resempphone.value,
                'resempadd1': resempadd1.value,
                'resempadd2': resempadd2.value,
                'resempcity': resempcity.value,
                'resempstate': resempstate.value,
                'resempzip': resempzip.value,
                'resemphiredate': resemphiredate.value,
                'resemptype': resemptype.value,
                'resempsalary': resempsalary.value,
                'userid': userid.value,
            },

            dataType: 'json',
            cache: false,
            success: function (data) {
                this.setState({ data: data });
            }.bind(this),
            error: function (xhr, status, err) {
                console.error(this.props.url, status, err.toString());
            }.bind(this)
        });
    },
    componentDidMount: function () {
        this.loadEmployeeFromServer();
    },

    render: function () {
        return (
            <div>
                <center>
                    <EmployeeSearchForm onEmployeeSubmit={this.loadEmployeeFromServer} />
                    <br />
                    <table>
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>First Name</th>
                                <th>Last Name</th>
                                <th>Date of Birth</th>
                                <th>Email</th>
                                <th>Phone</th>
                                <th>Address 1</th>
                                <th>Address 2</th>
                                <th>City</th>
                                <th>State</th>
                                <th>Zipcode</th>
                                <th>Hire Date</th>
                                <th>Type</th>
                                <th>Salary</th>
                                <th>User ID</th>
                            </tr>
                        </thead>
                        <EmployeeList data={this.state.data} />
                    </table>
                </center>
            </div>
        );
    }
});

var EmployeeSearchForm = React.createClass({

    getInitialState: function () {
        return {
            resempid: "",
            resempfname: "",
            resemplname: "",
            resempdob: "",
            resempemail: "",
            resempphone: "",
            resempadd1: "",
            resempadd2: "",
            resempcity: "",
            resempstate: "",
            resempzip: "",
            resemphiredate: "",
            resemptype: "",
            resempsalary: "",
            userid: "",
        };
    },

    handleSubmit: function (e) {
        e.preventDefault();

        var resempid = this.state.resempid.trim();
        var resempfname = this.state.resempfname.trim();
        var resemplname = this.state.resemplname.trim();
        var resempdob = this.state.resempdob.trim();
        var resempemail = this.state.resempemail.trim();
        var resempphone = this.state.resempphone.trim();
        var resempadd1 = this.state.resempadd1.trim();
        var resempadd2 = this.state.resempadd2.trim();
        var resempcity = this.state.resempcity.trim();
        var resempstate = this.state.resempstate.trim();
        var resempzip = this.state.resempzip.trim();
        var resemphiredate = this.state.resemphiredate.trim();
        var resemptype = this.state.resemptype.trim();
        var resempsalary = this.state.resempsalary.trim();
        var userid = this.state.userid.trim();


        this.props.onEmployeeSubmit({
            resempid: resempid,
            resempfname: resempfname,
            resemplname: resemplname,
            resempdob: resempdob,
            resempemail: resempemail,
            resempphone: resempphone,
            resempadd1: resempadd1,
            resempadd2: resempadd2,
            resempcity: resempcity,
            resempstate: resempstate,
            resempzip: resempzip,
            resemphiredate: resemphiredate,
            resemptype: resemptype,
            resempsalary: resempsalary,
            userid: userid,
        });
    },

    handleChange: function (event) {
        this.setState({
            [event.target.id]: event.target.value
        });
    },

    render: function () {
        return (
            <center>
                <form className="EmployeeSearchForm" onSubmit={this.handleSubmit}>
                    <h1>Search an Employee</h1>
                    <table border>
                        <tbody>
                            <tr>
                                <th>ID</th>
                                <td>
                                    <input name="resempid" id="resempid"
                                        value={this.state.resempid} onChange={this.handleChange} />
                                </td>
                            </tr>

                            <tr>
                                <th>First Name</th>
                                <td>
                                    <input name="resempfname" id="resemplname"
                                        value={this.state.resempfname} onChange={this.handleChange} />
                                </td>
                            </tr>
                            <tr>
                                <th>Last Name</th>
                                <td>
                                    <input name="resemplname" id="resemplname"
                                        value={this.state.resemplname} onChange={this.handleChange} />
                                </td>
                            </tr>

                            <tr>
                                <th>Date of Birth</th>
                                <td>
                                    <input name="resempdob" id="resempdob"
                                        value={this.state.resempdob} onChange={this.handleChange} />
                                </td>
                            </tr>

                            <tr>
                                <th>Email</th>
                                <td>
                                    <input name="resempemail" id="resempemail"
                                        value={this.state.resempemail} onChange={this.handleChange} />
                                </td>
                            </tr>

                            <tr>
                                <th>Phone</th>
                                <td>
                                    <input name="resempphone" id="resempphone"
                                        value={this.state.resempphone} onChange={this.handleChange} />
                                </td>
                            </tr>

                            <tr>
                                <th>Address 1</th>
                                <td>
                                    <input name="resempadd1" id="resempadd1"
                                        value={this.state.resempadd1} onChange={this.handleChange} />
                                </td>
                            </tr>
                            <tr>
                                <th>Address 2</th>
                                <td>
                                    <input name="resempadd2" id="resempadd2"
                                        value={this.state.resempadd2} onChange={this.handleChange} />
                                </td>
                            </tr>

                            <tr>
                                <th>City</th>
                                <td>
                                    <input name="resempcity" id="resempcity"
                                        value={this.state.resempcity} onChange={this.handleChange} />
                                </td>
                            </tr>

                            <tr>
                                <th>State</th>
                                <td>
                                    <input name="resempstate" id="resempstate"
                                        value={this.state.resempstate} onChange={this.handleChange} />
                                </td>
                            </tr>

                            <tr>
                                <th>Zipcode</th>
                                <td>
                                    <input name="resempzip" id="resempzip"
                                        value={this.state.resempzip} onChange={this.handleChange} />
                                </td>
                            </tr>

                            <tr>
                                <th>Hire Date</th>
                                <td>
                                    <input name="resemphiredate" id="resemphiredate"
                                        value={this.state.resemphiredate} onChange={this.handleChange} />
                                </td>
                            </tr>
                            <tr>
                                <th>Type</th>
                                <td>
                                    <input name="resemptype" id="resemptype"
                                        value={this.state.resemptype} onChange={this.handleChange} />
                                </td>
                            </tr>

                            <tr>
                                <th>Salary</th>
                                <td>
                                    <input name="resempsalary" id="resempsalary"
                                        value={this.state.resempsalary} onChange={this.handleChange} />
                                </td>
                            </tr>

                            <tr>
                                <th>User ID</th>
                                <td>
                                    <input name="userid" id="userid"
                                        value={this.state.userid} onChange={this.handleChange} />
                                </td>
                            </tr>

                        </tbody>
                    </table> <br />
                    <input type="submit" name="thesubmit" value="Search" id="thesubmit" />

                </form>
            </center>
        );
    }
});


var EmployeeList = React.createClass({
    render: function () {
        var EmployeeNodes = this.props.data.map(function (Employee) {
            return (
                <Employee
                    key={Employee.resempid}
                    efname={Employee.resempfname}
                    elname={Employee.resemplname}
                    edob={Employee.resempdob}
                    eemail={Employee.resempemail}
                    ephone={Employee.resempphone}
                    eadd1={Employee.resempadd1}
                    eadd2={Employee.resempadd2}
                    ecity={Employee.resemployee}
                    estate={Employee.resemployee}
                    ezip={Employee.resemployee}
                    ehd={Employee.resemployee}
                    etype={Employee.resemployee}
                    esal={Employee.resemployee}
                    euid={Employee.resemployee}
                >
                </Employee>
            );

        });

        return (
            <tbody>
                {EmployeeNodes}
            </tbody>
        );
    }
});



var Employee = React.createClass({

    render: function () {
        return (

            <tr>

                <td>
                    {this.props.key}
                </td>
                <td>
                    {this.props.efname} 
                </td>
                <td>
                    {this.props.elname}
                </td>
                <td>
                    {this.props.edob}
                </td>
                <td>
                    {this.props.eemail}
                </td>
                <td>
                    {this.props.ephone}
                </td>
                <td>
                    {this.props.eadd1}
                </td>
                <td>
                    {this.props.eadd2}
                </td>
                <td>
                    {this.props.ecity}
                </td>
                <td>
                    {this.props.estate}
                </td>
                <td>
                    {this.props.ezip}
                </td>
                <td>
                    {this.props.ehd}
                </td>
                <td>
                    {this.props.etype}
                </td>
                <td>
                    {this.props.esal}
                </td>
                <td>
                    {this.props.euid}
                </td>
            </tr>
        );
    }
});


ReactDOM.render(
    <EmployeeSearchBox />,
    document.getElementById('content')
);
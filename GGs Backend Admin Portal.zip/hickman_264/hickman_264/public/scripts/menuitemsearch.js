var MenuSearchBox = React.createClass({

    getInitialState: function () {
        return { data: [] };
    },

    loadMenuFromServer: function () {
        $.ajax({
            url: '/menusearch',
            data: {
                'mitemkey': mitemkey.value,
                'mitemname': mitemname.value,
                'mitemdescrip': mitemdescrip.value,
                'mitemprice': mitemprice.value,
            },
            dataType: 'json',
            cache: false,
            success: function (data) {
                this.setState({ data: data });
            }.bind(this),
            error: function (xhr, status, err) {
                console.error(this.props.url, status, err.toString());
            }.bind(this)
        });

    },

    componentDidMount: function () {
        this.loadMenuFromServer();
    },

    render: function () {
        return (
            <div>
                <center>
                    <MenuSearchForm onMenuSubmit={this.loadMenuFromServer} />
                    <br />
                    <table>
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Description</th>
                                <th>Price</th>
                            </tr>
                        </thead>
                        <MenuList data={this.state.data} />
                    </table>
                </center>
            </div>
        );
    }
});

var MenuSearchForm = React.createClass({

    getInitialState: function () {
        return {
            mitemkey: "",
            mitemname: "",
            mitemdescrip: "",
            mitemprice: ""
        };
    },

    handleSubmit: function (e) {
        e.preventDefault();

        var mitemkey = this.state.mitemkey.trim();
        var mitemname = this.state.mitemname.trim();
        var mitemdescrip = this.state.mitemdescrip.trim();
        var mitemprice = this.state.mitemprice.trim();


        this.props.onMenuSubmit({
            mitemkey: mitemkey,
            mitemname: mitemname,
            mitemdescrip: mitemdescrip,
            mitemprice: mitemprice
        });
    },

    handleChange: function (event) {
        this.setState({
            [event.target.id]: event.target.value
        });
    },

    render: function () {
        return (
            <center>
                <form className="MenuSearchForm" onSubmit={this.handleSubmit}>
                    <h1>Search the Menu</h1>
                    <table border>
                        <tbody>
                            <tr>
                                <th>Menu Item ID</th>
                                <td>
                                    <input name="mitemkey" id="mitemkey"
                                        value={this.state.mitemkey} onChange={this.handleChange} />
                                </td>
                            </tr>

                            <tr>
                                <th>Menu Item Name</th>
                                <td>
                                    <input name="mitemname" id="mitemname"
                                        value={this.state.mitemname} onChange={this.handleChange} />
                                </td>
                            </tr>
                            <tr>
                                <th>Menu Item Description</th>
                                <td>
                                    <input name="mitemdescrip" id="mitemdescrip"
                                        value={this.state.mitemdescrip} onChange={this.handleChange} />
                                </td>
                            </tr>

                            <tr>
                                <th>Menu Item Unit Price</th>
                                <td>
                                    <input name="mitemprice" id="mitemprice"
                                        value={this.state.mitemprice} onChange={this.handleChange} />
                                </td>
                            </tr>

                        </tbody>
                    </table> <br />
                    <input type="submit" name="thesubmit" value="Search" id="thesubmit" />

                </form>
            </center>
        );
    }
});


var MenuList = React.createClass({
    render: function () {
        var MenuNodes = this.props.data.map(function (Menu) {
            return (
                <Menu
                    key={Menu.mitemkey}
                    mname={Menu.mitemname}
                    mdesc={Menu.mitemdescrip}
                    mprice={Menu.mitemprice}
                >
                </Menu>
            );

        });

        return (
            <tbody>
                {MenuNodes}
            </tbody>
        );
    }
});



var Menu = React.createClass({

    render: function () {
        return (

            <tr>

                <td>
                    {this.props.key}
                </td>
                <td>
                    {this.props.mname}
                </td>
                <td>
                    {this.props.mdesc}
                </td>
                <td>
                    {this.props.mprice}
                </td>
            </tr>
        );
    }
});


ReactDOM.render(
    <MenuSearchBox />,
    document.getElementById('content')
);
var CustomerSearchBox = React.createClass({

    getInitialState: function () {
        return { data: [] };
    },

    loadCustomerFromServer: function () {
        $.ajax({
            url: '/customersearch',
            data: {
                'cusid': cusid.value,
                'cusfname': cusfname.value,
                'cuslname': cuslname.value,
                'cusphone': cusphone.value,
                'cusemail': cusemail.value,
            },
            dataType: 'json',
            cache: false,
            success: function (data) {
                this.setState({ data: data });
            }.bind(this),
            error: function (xhr, status, err) {
                console.error(this.props.url, status, err.toString());
            }.bind(this)
        });

    },
    componentDidMount: function () {
        this.loadCustomerFromServer();
    },

    render: function () {
        return (
            <div>
                <center>
                    <CustomerSearchForm onCustomerSubmit={this.loadCustomerFromServer} />
                    <br />
                    <table>
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>First Name</th>
                                <th>Last Name</th>
                                <th>Phone</th>
                                <th>Email</th>
                            </tr>
                        </thead>
                        <CustomerList data={this.state.data} />
                    </table>
                </center>
            </div>
        );
    }
});

var CustomerSearchForm = React.createClass({
    getInitialState: function () {

        return {
            cusid: "",
            cusfname: "",
            cuslname: "",
            cusphone: "",
            cusemail: "",
        };
    },

    handleSubmit: function (e) {
        e.preventDefault();

        var cusid = this.state.cusid.trim();
        var cusfname = this.state.cusfname.trim();
        var cuslname = this.state.cuslname.trim();
        var cusphone = this.state.cusphone.trim();
        var cusemail = this.state.cusemail.trim();


        this.props.onCustomerSubmit({
            cusid: cusid,
            cusfname: cusfname,
            cuslname: cuslname,
            cusphone: cusphone,
            cusemail: cusemail
        });
    },

    handleChange: function (event) {
        this.setState({
            [event.target.id]: event.target.value
        });
    },

    render: function () { return (
            <center>
                <form className="CustomerSearchForm" onSubmit={this.handleSubmit}>
                <h1>Search a Customer</h1>
                <table border>
                        <tbody>
                            <tr>
                                <th>Customer ID</th>
                                <td>
                                    <input name="cusid" id="cusid"
                                        value={this.state.cusid} onChange={this.handleChange} />
                                </td>
                            </tr>

                            <tr>
                                <th>Customer First Name</th>
                                <td>
                                    <input name="cusfname" id="cusfname"
                                        value={this.state.cusfname} onChange={this.handleChange} />
                                </td>
                            </tr>
                            <tr>
                                <th>Customer Last Name</th>
                                <td>
                                    <input name="cuslname" id="cuslname"
                                        value={this.state.cuslname} onChange={this.handleChange} />
                                </td>
                            </tr>

                            <tr>
                                <th>Customer Phone</th>
                                <td>
                                <input name="cusphone" id="cusphone"
                                    value={this.state.cusphone} onChange={this.handleChange} />

                                </td>
                            </tr>

                            <tr>
                                <th>Customer Email</th>
                                <td>
                                <input name="cusemail" id="cusemail"
                                    value={this.state.cusemail} onChange={this.handleChange} />

                                </td>
                            </tr>

                        </tbody>
                    </table> <br />
                    <input type="submit" name="thesubmit" value="Search" id="thesubmit" />

                </form>
            </center>
        );
    }
});


var CustomerList = React.createClass({
    render: function () {
        var customerNodes = this.props.data.map(function (customer) {
            return (
                <Customer
                    key={customer.cusid}
                    cusid={customer.cusid}
                    cusfname={customer.cusfname}
                    cuslname={customer.cuslname}
                    cusphone={customer.cusphone}
                    cusemail={customer.cusemail}
                >
                </Customer>
            );

        });

        return (
            <tbody>
                {customerNodes}
            </tbody>
        );
    }
});



var Customer = React.createClass({

    render: function () {        return (

            <tr>
                <td>
                    {this.props.cusid}
                </td>
            <td>
                {this.props.cusfname}
                </td>
            <td>
                {this.props.cuslname}
                </td>
            <td>
                {this.props.cusphone}
                </td>
            <td>
                {this.props.cusemail}
                </td>
            </tr>
        );
    }
});


ReactDOM.render(
    <CustomerSearchBox />,
    document.getElementById('content')
);
var CustomerUpdateBox = React.createClass({
    getInitialState: function () {
        return { data: [] };
    },

    loadCustomerFromServer: function () {
        $.ajax({
            url: '/customersearch',
            data: {
                'cusid': cusid.value,
                'cusfname': cusfname.value,
                'cuslname': cuslname.value,
                'cusphone': cusphone.value,
                'cusemail': cusemail.value,
            },
            dataType: 'json',
            cache: false,
            success: function (data) {
                this.setState({ data: data });
            }.bind(this),
            error: function (xhr, status, err) {
                console.error(this.props.url, status, err.toString());
            }.bind(this)
        });

    },
    updateSingleCustomerFromServer: function (Customer) {
        $.ajax({
            url: '/getsinglecustomer',
            dataType: 'json',
            data: Customer,
            type: 'POST',
            cache: false,
            success: function (upsingledata) {
                this.setState({ upsingledata: upsingledata });
            }.bind(this),
            error: function (xhr, status, err) {
                console.error(this.props.url, status, err.toString());
            }.bind(this)
        });
        window.location.reload(true);
    },
    componentDidMount: function () {
        this.loadCustomerFromServer();
    },

    render: function () {
        return (
            <div>
                <CustomerUpdateForm onCustomerSubmit={this.loadCustomerFromServer} />
                <br />
                <div id="theresults">
                    <div id="theleft">
                        <table>
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>First Name</th>
                                    <th>Last Name</th>
                                    <th>Phone</th>
                                    <th>Email</th>
                                </tr>
                            </thead>
                            <CustomerList data={this.state.data} />
                        </table>
                    </div>
                    <div id="theright">
                        <CustomerUpdateform onUpdateSubmit={this.updateSingleCustomerFromServer} />
                    </div>
                </div>
            </div>
        );
    }
});

var CustomerUpdateForm = React.createClass({
    getInitialState: function () {
        return {
            cusid: "",
            cusfname: "",
            cuslname: "",
            cusphone: "",
            cusemail: "",
            data: []
        };
    },

    submithandle: function (e) {
        e.preventDefault();

        var cusid = this.state.cusid.trim();
        var cusfname = this.state.cusfname.trim();
        var cuslname = this.state.cuslname.trim();
        var cusphone = this.state.cusphone.trim();
        var cusemail = this.state.cusemail.trim();

        this.props.onCustomerSubmit({
            cusid: cusid,
            cusfname: cusfname,
            cuslname: cuslname,
            cusphone: cusphone,
            cusemail: cusemail
        });
    },
    handleChange: function (event) {
        this.setState({
            [event.target.id]: event.target.value
        });
    },
    render: function () {

        return (
            <center>
                <form onSubmit={this.submithandle}>

                    <table border>
                        <tbody>
                            <tr>
                                <th>Customer ID</th>
                                <td>
                                    <input name="cusid" id="cusid"
                                        value={this.state.cusid} onChange={this.handleChange} />
                                </td>
                            </tr>

                            <tr>
                                <th>Customer First Name</th>
                                <td>
                                    <input name="cusfname" id="cusfname"
                                        value={this.state.cusfname} onChange={this.handleChange} />
                                </td>
                            </tr>
                            <tr>
                                <th>Customer Last Name</th>
                                <td>
                                    <input name="cuslname" id="cuslname"
                                        value={this.state.cuslname} onChange={this.handleChange} />
                                </td>
                            </tr>

                            <tr>
                                <th>Customer Phone</th>
                                <td>
                                    <input name="cusphone" id="cusphone"
                                        value={this.state.cusphone} onChange={this.handleChange} />

                                </td>
                            </tr>

                            <tr>
                                <th>Customer Email</th>
                                <td>
                                    <input name="cusemail" id="cusemail"
                                        value={this.state.cusemail} onChange={this.handleChange} />

                                </td>
                            </tr>
                        </tbody>
                    </table><br />
                    <input type="submit" name="thesubmit" value="Update" id="thesubmit" />
                </form>

                <div>
                    <br />
                    <form onSubmit={this.getInitialState}>
                        <input type="submit" value="Reset Forms" />
                    </form>
                </div>
            </center>
        );
    }
});

var CustomerUpdateform = React.createClass({
    getInitialState: function () {
        return {
            upCusid: "",
            upCusfname: "",
            upCuslname: "",
            upCusphone: "",
            upCusemail: "",
            updata: []
        };
    },

    handleUpSubmit: function (e) {
        e.preventDefault();

        var upCusid = cusid.value;
        var upCusfname = cusfname.value;
        var upCuslname = cuslname.value;
        var upCusphone = cusphone.value;
        var upCusemail = cusemail.value;


        this.props.onUpdateSubmit({
            upCusid: upCusid,
            upCusfname: upCusfname,
            upCuslname: upCuslname,
            upCusphone: upCusphone,
            upCusemail: upCusemail
        });

    },
    handleUpChange: function (event) {
        this.setState({
            [event.target.id]: event.target.value
        });
    },
    render: function () {

        return (
            <center>
                <div>
                    <div id="theform">
                        <form onSubmit={this.handleUpSubmit}>

                            <table>
                                <tbody>
                            <tr>
                                    <th>Customer ID</th>
                                    <td>
                                        <input name="upCusid" id="upCusid"
                                            value={this.state.upCusid} onChange={this.handleChange} />
                                    </td>
                            </tr>

                                <tr>
                                    <th>Customer First Name</th>
                                    <td>
                                        <input name="upCusfname" id="upCusfname"
                                            value={this.state.upCusfname} onChange={this.handleChange} />
                                    </td>
                                </tr>
                                <tr>
                                    <th>Customer Last Name</th>
                                    <td>
                                        <input name="upCuslname" id="upCuslname"
                                            value={this.state.upCuslname} onChange={this.handleChange} />
                                    </td>
                                </tr>

                                <tr>
                                    <th>Customer Phone</th>
                                    <td>
                                        <input name="upCusphone" id="upCusphone"
                                            value={this.state.upCusphone} onChange={this.handleChange} />

                                    </td>
                                </tr>

                                <tr>
                                    <th>Customer Email</th>
                                    <td>
                                        <input name="upCusemail" id="upCusemail"
                                            value={this.state.upCusemail} onChange={this.handleChange} />

                                    </td>
                                </tr>
                                </tbody>
                            </table><br />
                            <input type="hidden" name="upCusid" id="upCusid" onChange={this.handleUpChange} />
                            <input type="submit" id="theupdate" value="Update" />
                        </form>
                    </div>
                </div></center>
        );
    }
});

var CustomerList = React.createClass({
    render: function () {
        var CustomerNodes = this.props.data.map(function (Customer) {
            return (
                <Customer
                    key={customer.cusid}
                    cusid={customer.cusid}
                    cusfname={customer.cusfname}
                    cuslname={customer.cuslname}
                    cusphone={customer.cusphone}
                    cusemail={customer.cusemail}
                >
                </Customer>
            );
        });
        return (
            <tbody>
                {CustomerNodes}
            </tbody>
        );
    }
});

var Customer = React.createClass({
    getInitialState: function () {
        return {
            upCusid: "",
            singledata: []
        };
    },
    updateRecord: function (e) {
        e.preventDefault();
        var theupCusid = this.props.cusid;

        this.loadSingleEmp(theupCusid);
    },
    loadSingleEmp: function (theupCusid) {
        $.ajax({
            url: '/getsinglecustomer',
            data: {
                'upCusid': theupCusid
            },
            dataType: 'json',
            cache: false,
            success: function (data) {
                this.setState({ singledata: data });
                console.log(this.state.singledata);
                var populateEmp = this.state.singledata.map(function (Customer) {
                    upCusid.value = theupCusid;
                    upCusfname.value = Customer.cusfname;
                    upCuslname.value = Customer.cuslname;
                    upCusphone.value = Customer.cusphone;
                    upCusemail.value = Customer.cusemail;
                });
            }.bind(this),
            error: function (xhr, status, err) {
                console.error(this.props.url, status, err.toString());
            }.bind(this)
        });
    },

    render: function () {

        return (

            <tr>

                <td>
                    {this.props.cusid}
                </td>
                <td>
                    {this.props.cusfname}
                </td>
                <td>
                    {this.props.cuslname}
                </td>
                <td>
                    {this.props.cusphone}
                </td>
                <td>
                    {this.props.cusemail}
                </td>
                <td>
                    <form onSubmit={this.updateRecord}>

                        <input type="submit" value="Edit" />
                    </form>
                </td>
            </tr>
        );
    }
});


ReactDOM.render(
    <CustomerUpdateBox />,
    document.getElementById('content')
);


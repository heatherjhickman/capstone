var UserSearchBox = React.createClass({

    getInitialState: function () {
        return { data: [] };
    },

    loadUserFromServer: function () {
        $.ajax({
            url: '/userssearch',
            data: {
                'userid': userid.value,
                'employeeid': employeeid.value,
                'username': username.value,
                'password': password.value,
                'seclvl': seclvl.value,
            },
            dataType: 'json',
            cache: false,
            success: function (data) {
                this.setState({ data: data });
            }.bind(this),
            error: function (xhr, status, err) {
                console.error(this.props.url, status, err.toString());
            }.bind(this)
        });

    },
    componentDidMount: function () {
        this.loadUserFromServer();
    },

    render: function () {
        return (
            <div>
                <center>
                    <UserSearchForm onUserSubmit={this.loadUserFromServer} />
                    <br />
                    <table>
                        <thead>
                            <tr>
                                <th>User ID</th>
                                <th>Employee ID</th>
                                <th>Username</th>
                                <th>Password</th>
                                <th>Security Level</th>
                            </tr>
                        </thead>
                        <UserList data={this.state.data} />
                    </table>
                </center>
            </div>
        );
    }
});

var UserSearchForm = React.createClass({

    getInitialState: function () {
        return {
            userid: "",
            employeeid: "",
            username: "",
            password: "",
            seclvl: "",
        };
    },

    handleSubmit: function (e) {
        e.preventDefault();

        var userid = this.state.userid.trim();
        var employeeid = this.state.employeeid.trim();
        var username = this.state.username.trim();
        var password = this.state.password.trim();
        var seclvl = this.state.seclvl.trim();


        this.props.onUserSubmit({
            userid: userid,
            employeeid: employeeid,
            username: username,
            password: password,
            seclvl: seclvl,
        });
    },

    handleChange: function (event) {
        this.setState({
            [event.target.id]: event.target.value
        });
    },

    render: function () {
        return (
            <center>
                <form className="UserSearchForm" onSubmit={this.handleSubmit}>
                    <h1>Search a User</h1>
                    <table border>
                        <tbody>
                            <tr>
                                <th>User ID</th>
                                <td>
                                    <input name="userid" id="userid"
                                        value={this.state.userid} onChange={this.handleChange} />
                                </td>
                            </tr>

                            <tr>
                                <th>Employee ID</th>
                                <td>
                                    <input name="employeeid" id="employeeid"
                                        value={this.state.employeeid} onChange={this.handleChange} />
                                </td>
                            </tr>
                            <tr>
                                <th>Username</th>
                                <td>
                                    <input name="username" id="username"
                                        value={this.state.username} onChange={this.handleChange} />
                                </td>
                            </tr>

                            <tr>
                                <th>Password</th>
                                <td>
                                    <input name="password" id="password"
                                        value={this.state.password} onChange={this.handleChange} />
                                </td>
                            </tr>

                            <tr>
                                <th>Security Level</th>
                                <td>
                                    <input name="seclvl" id="seclvl"
                                        value={this.state.seclvl} onChange={this.handleChange} />
                                </td>
                            </tr>

                        </tbody>
                    </table> <br />
                    <input type="submit" name="thesubmit" value="Search" id="thesubmit" />

                </form>
            </center>
        );
    }
});


var UserList = React.createClass({
    render: function () {
        var UserNodes = this.props.data.map(function (User) {
            return (
                <User
                    key={User.userid}
                    eid={User.employeeid}
                    un={User.username}
                    pass={User.password}
                    slvl={User.seclvl}
                >
                </User>
            );

        });

        return (
            <tbody>
                {UserNodes}
            </tbody>
        );
    }
});



var User = React.createClass({

    render: function () {
        return (

            <tr>

                <td>
                    {this.props.key}
                </td>
                <td>
                    {this.props.eid}
                </td>
                <td>
                    {this.props.un}
                </td>
                <td>
                    {this.props.pass}
                </td>
                <td>
                    {this.props.slvl}
                </td>
            </tr>
        );
    }
});


ReactDOM.render(
    <UserSearchBox />,
    document.getElementById('content')
);
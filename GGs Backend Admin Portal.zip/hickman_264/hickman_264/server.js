'use strict';

// CONNECTION INFORMATION
var fs = require('fs');
var path = require('path');
var express = require('express');
var bodyParser = require('body-parser');
var app = express();

const mysql = require('mysql2');

const connection = mysql.createConnection({
    host: "istwebclass.org",
    user: "hhickma1_capUser",
    password: "password",
    database: "hhickma1_capstone264hotel"
});

connection.connect(function (err) {
    if (err) throw err;
    console.log("Connected!");
});

app.set('port', (process.env.PORT || 3000));
app.use('/', express.static(path.join(__dirname, 'public')));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.get('/', function (req, res) {
    res.sendFile(path.join(__dirname + '/public/main-login.html'));
});



// ACCESS USER INFORMATION
// insert
app.post('/userinsert', function (req, res) {
    var uid = req.body.userid;
    var uemid = req.body.employeeid;
    var uusername = req.body.username;
    var upass = req.body.password;
    var useclvl = req.body.seclvl;
    console.log(uid);

    var sqlins = "INSERT INTO users (userid, employeeid, username, password, seclvl) VALUES (?, ?, ?, ?, ?)";
    var inserts = [uid, uemid, uusername, upass, useclvl];
    var sql = mysql.format(sqlins, inserts);

    connection.execute(sql, function (err, result) {
        if (err) throw err;
        console.log("1 record inserted");
        res.redirect('userinsert.html');
        res.end();
    });
});


// search
app.get('/userssearch', function (req, res) {
    var uid = req.query.userid;
    var uemid = req.query.employeeid;
    var uusername = req.query.username;
    var upass = req.query.password;
    var useclvl = req.query.seclvl;

    var selectSQL = 'Select * from users where userid Like ? and employeeid Like ? and username Like ? and password Like ? and seclvl Like ?';
    var selects = ['%' + uid + '%', '%' + uemid + '%', '%' + uusername + '%', '%' + upass + '%', '%' + useclvl + '%'];
    var sql = mysql.format(selectSQL, selects);

    console.log(sql);
    console.log(selects);

    connection.query(sql, function (err, data) {
        if (err) {
            console.error(err);
            process.exit(1);}
        res.send(JSON.stringify(data));
    });
});


// get a single user
app.get('/getsingleuser/', function (req, res) {

    var uid = req.query.userid;

    var sqlsel = 'select * from users where userid = ?';
    var inserts = [uid];

    var sql = mysql.format(sqlsel, inserts);

    connection.query(sql, function (err, data) {
        if (err) {
            console.error(err);
            process.exit(1);
        }
        res.send(JSON.stringify(data));
    });
});


// update
app.post('/usersupdate', function (req, res, ) {
    var uid = req.body.userid;
    var uemid = req.body.employeeid;
    var uusername = req.body.username;
    var upass = req.body.password;
    var useclvl = req.body.seclvl;

    var sqlins = "UPDATE users SET userid = ?, employeeid = ?, username = ?, password = ?, seclvl = ?";
    var inserts = [uid, uemid, uusername, upass, useclvl];
    var sql = mysql.format(sqlins, inserts);

    console.log(sql);
    connection.execute(sql, function (err, result) {
        if (err) throw err;
        console.log("1 record updated");
        res.end();
    });
});



// ACCESS RESTAURANT EMPLOYEE INFORMATION
// insert
app.post('/employeeinsert', function (req, res) {
    var empid = req.body.resempid;
    var empfname = req.body.resempfname;
    var emplname = req.body.resemplname;
    var empdob = req.body.resempdob;
    var empmail = req.body.resempemail;
    var empphone = req.body.resempphone;
    var empadd1 = req.body.resempadd1;
    var empadd2 = req.body.resempadd2;
    var empcity = req.body.resempcity;
    var empstate = req.body.resempstate;
    var empzip = req.body.resempzip;
    var emphired = req.body.resemphiredate;
    var emptype = req.body.resemptype;
    var empsalary = req.body.resempsalary;
    var empuserid = req.body.userid;
    console.log(empid);

    var sqlins = "INSERT INTO resemployee (resempid, resempfname, resemplname, resempdob, resempemail, resempphone, resempadd1, resempadd2, resempcity, resempstate, resempzip, resemphiredate," +
    " resemptype, resempsalary, userid) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    var inserts = [empid, empfname, emplname, empdob, empmail, empphone, empadd1, empadd2, empcity, empstate, empzip, emphired, emptype, empsalary, empuserid];
    var sql = mysql.format(sqlins, inserts);

    connection.execute(sql, function (err, result) {
        if (err) throw err;
        console.log("1 record inserted");
        res.redirect('resemployeeinsert.html');
        res.end();
    });
});


// search
app.get('/employeesearch', function (req, res) {
    var empid = req.query.resempid;
    var empfname = req.query.resempfname;
    var emplname = req.query.resemplname;
    var empdob = req.query.resempdob;
    var empmail = req.query.resempemail;
    var empphone = req.query.resempphone;
    var empadd1 = req.query.resempadd1;
    var empadd2 = req.query.resempadd2;
    var empcity = req.query.resempcity;
    var empstate = req.query.resempstate;
    var empzip = req.query.resempzip;
    var emphired = req.query.resemphiredate;
    var emptype = req.query.resemptype;
    var empsalary = req.query.resempsalary;
    var empuserid = req.query.userid;

    var selectSQL = 'Select * from resemployee where resempid Like ? and resempfname Like ? and resemplname Like ? and resempdob Like ? and resempemail Like ? and resempphone Like ? ' +
        ' and resempadd1 Like ? and resempadd2 Like ? and resempcity Like ? and resempstate Like ? and resempzip Like ? and resemphired Like ? and resemptype Like ? '+
        ' and resempsalary Like ? and userid Like ? ';
    var selects = ['%' + empid + '%', '%' + empfname + '%', '%' + emplname + '%', '%' + empdob + '%', '%' + empmail + '%', '%' + empphone + '%', '%' + empadd1 + '%', '%' + empadd2 + '%'
        , '%' + empcity + '%', '%' + empstate + '%', '%' + empzip + '%', '%' + emphired + '%', '%' + emptype + '%', '%' + empsalary + '%', '%' + empuserid + '%'];
    var sql = mysql.format(selectSQL, selects);

    console.log(sql);
    console.log(selects);
    connection.query(sql, function (err, data) {
        if (err) {
            console.error(err);
            process.exit(1); }
        res.send(JSON.stringify(data));
    });
});


// get a single employee
app.get('/getsingleemployee/', function (req, res) {

    var empid = req.query.resempid;

    var sqlsel = 'select * from resemployee where resempid = ?';
    var inserts = [empid];

    var sql = mysql.format(sqlsel, inserts);

    connection.query(sql, function (err, data) {
        if (err) {
            console.error(err);
            process.exit(1);
        }
        res.send(JSON.stringify(data));
    });
});


// update
app.post('/employeeupdate', function (req, res, ) {
    var empid = req.body.resempid;
    var empfname = req.body.resempfname;
    var emplname = req.body.resemplname;
    var empdob = req.body.resempdob;
    var empmail = req.body.resempemail;
    var empphone = req.body.resempphone;
    var empadd1 = req.body.resempadd1;
    var empadd2 = req.body.resempadd2;
    var empcity = req.body.resempcity;
    var empstate = req.body.resempstate;
    var empzip = req.body.resempzip;
    var emphired = req.body.resemphiredate;
    var emptype = req.body.resemptype;
    var empsalary = req.body.resempsalary;
    var empuserid = req.body.userid;

    var sqlins = "UPDATE resemployee SET resempid = ?, resempfname = ?, resemplname = ?, resempdob = ?, resempemail = ?, resempphone = ?, resempadd1 = ?, resempadd2 = ?, resempcity = ? " +
        ", resempstate = ?, resempzip = ?, resemphired = ?, resemptype = ?, resempsalary = ?, userid = ? ";
    var inserts = [empid, empfname, emplname, empdob, empmail, empphone, empadd1, empadd2, empcity, empstate, empzip, emphired, emptype, empsalary, empuserid];
    var sql = mysql.format(sqlins, inserts);

    console.log(sql);
    connection.execute(sql, function (err, result) {
        if (err) throw err;
        console.log("1 record updated");
        res.end();
    });
});



// ACCESS CUSTOMER INFORMATION
// insert
app.post('/customerinsert', function (req, res) {
    var cid = req.body.cusid;
    var cfname = req.body.cusfname;
    var clname = req.body.cuslname;
    var cphone = req.body.cusphone;
    var cemail = req.body.cusemail;
    console.log(cid);

    var sqlins = "INSERT INTO customer (cusid, cusfname, cuslname, cusphone, cusemail) VALUES(?, ?, ?, ?, ?)";
    var inserts = [cid, cfname, clname, cphone, cemail];
    var sql = mysql.format(sqlins, inserts);

    connection.execute(sql, function (err, result) {
        if (err) throw err;
        console.log("1 record inserted");
        res.redirect('customerinsert.html');
        res.end();
    });
});


// search
app.get('/customersearch', function (req, res) {
    var cid = req.query.cusid;
    var cfname = req.query.cusfname;
    var clname = req.query.cuslname;
    var cphone = req.query.cusphone;
    var cemail = req.query.cusemail;

    var selectSQL = 'Select * from customer where cusid Like ? and cusfname Like ? and cuslname Like ? and cusphone Like ? and cusemail Like ?';
    var selects = ['%' + cid + '%', '%' + cfname + '%', '%' + clname + '%', '%' + cphone + '%', '%' + cemail + '%'];
    var sql = mysql.format(selectSQL, selects);

    console.log(sql);
    console.log(selects);
    connection.query(sql, function (err, data) {
        if (err) {
            console.error(err);
            process.exit(1); }
        res.send(JSON.stringify(data));
    });
});


// get a single customer
app.get('/getsinglecustomer/', function (req, res) {

    var cid = req.query.cusid;

    var sqlsel = 'select * from customer where cusid = ?';
    var inserts = [cid];

    var sql = mysql.format(sqlsel, inserts);

    connection.query(sql, function (err, data) {
        if (err) {
            console.error(err);
            process.exit(1);
        }
        res.send(JSON.stringify(data));
    });
});


// update
app.post('/customerupdate', function (req, res, ) {
    var cid = req.body.cusid;
    var cfname = req.body.cusfname;
    var clname = req.body.cuslname;
    var cphone = req.body.cusphone;
    var cemail = req.body.cusemail;

    var sqlins = "UPDATE customer SET cusid = ?, cusfname = ?, cuslname = ?, cusphone = ?, cusemail = ? ";
    var inserts = [cid, cfname, clname, cphone, cemail];
    var sql = mysql.format(sqlins, inserts);

    console.log(sql);
    connection.execute(sql, function (err, result) {
        if (err) throw err;
        console.log("1 record updated");
        res.end();
    });
});



// ACCESS CUSTOMER ORDER INFORMATION
// insert
app.post('/orderinsert', function (req, res) {
    var ordkey = req.body.orderkey;
    var cusid = req.body.cusid;
    var reid = req.body.resempid;
    var orddate = req.body.orderdate;
    var ordtime = req.body.ordertime;
    var ordstat = req.body.orderstatus;
    console.log(ordkey);

    var sqlins = "INSERT INTO customerorder (orderkey, cusid, resempid, orderdate, ordertime, orderstatus) VALUES(?, ?, ?, ?, ?, ?)";
    var inserts = [ordkey, cusid, reid, orddate, ordtime, ordstat];
    var sql = mysql.format(sqlins, inserts);

    connection.execute(sql, function (err, result) {
        if (err) throw err;
        console.log("1 record inserted");
        res.redirect('customerorderinsert.html');
        res.end();
    });
});


// search
app.get('/ordersearch', function (req, res) {
    var ordkey = req.query.orderkey;
    var cusid = req.query.cusid;
    var reid = req.query.resempid;
    var orddate = req.query.orderdate;
    var ordtime = req.query.ordertime;
    var ordstat = req.query.orderstatus;

    var selectSQL = 'Select * from customerorder where orderkey Like ? and cusid Like ? and resempid Like ? and orderdate Like ? and ordertime Like ? and orderstatus Like ?';
    var selects = ['%' + ordkey + '%', '%' + cusid + '%', '%' + reid + '%', '%' + orddate + '%', '%' + ordtime + '%', '%' + ordstat + '%'];
    var sql = mysql.format(selectSQL, selects);

    console.log(sql);
    console.log(selects);
    connection.query(sql, function (err, data) {
        if (err) {
            console.error(err);
            process.exit(1); }
        res.send(JSON.stringify(data));
    });
});


// get a single order
app.get('/getsingleorder/', function (req, res) {

    var okey = req.query.orderkey;

    var sqlsel = 'select * from customerorder where orderkey = ?';
    var inserts = [okey];

    var sql = mysql.format(sqlsel, inserts);

    connection.query(sql, function (err, data) {
        if (err) {
            console.error(err);
            process.exit(1);
        }
        res.send(JSON.stringify(data));
    });
});


// update
app.post('/orderupdate', function (req, res, ) {
    var ordkey = req.body.orderkey;
    var cusid = req.body.cusid;
    var reid = req.body.resempid;
    var orddate = req.body.orderdate;
    var ordtime = req.body.ordertime;
    var ordstat = req.body.orderstatus;

    var sqlins = "UPDATE customerorder SET orderkey = ?, cusid = ?, resempid = ?, orderdate = ?, ordertime = ?, orderstatus = ? ";
    var inserts = [ordkey, cusid, reid, orddate, ordtime, ordstat];
    var sql = mysql.format(sqlins, inserts);

    console.log(sql);
    connection.execute(sql, function (err, result) {
        if (err) throw err;
        console.log("1 record updated");
        res.end();
    });
});



// ACCESS ORDER DETAIL INFORMATION
// insert
app.post('/orderdetailinsert', function (req, res) {
    var odekey = req.body.orderdetailkey;
    var ordkey = req.body.orderkey;
    var mikey = req.body.mitemkey;
    var itquan = req.body.itemquantity;
    console.log(odekey);

    var sqlins = "INSERT INTO orderdetail (orderdetailkey, orderkey, mitemkey, itemquantity) VALUES(?, ?, ?, ?)";
    var inserts = [odekey, ordkey, mikey, itquan];
    var sql = mysql.format(sqlins, inserts);

    connection.execute(sql, function (err, result) {
        if (err) throw err;
        console.log("1 record inserted");
        res.redirect('orderdetailinsert.html');
        res.end();
    });
});


// search
app.get('/orderdetailsearch', function (req, res) {
    var odekey = req.query.orderdetailkey;
    var ordkey = req.query.orderkey;
    var mikey = req.query.mitemkey;
    var itquan = req.query.itemquantity;

    var selectSQL = 'Select * from orderdetail where orderdetailkey Like ? and orderkey Like ? and mitemkey Like ? and itemquantity Like ?';
    var selects = ['%' + odekey + '%', '%' + ordkey + '%', '%' + mikey + '%', '%' + itquan + '%'];
    var sql = mysql.format(selectSQL, selects);

    console.log(sql);
    console.log(selects);

    connection.query(sql, function (err, data) {
        if (err) {
            console.error(err);
            process.exit(1); }
        res.send(JSON.stringify(data));
    });
});


// get a single orderdetail
app.get('/getsingleorderdetail/', function (req, res) {

    var odekey = req.query.orderdetailkey;

    var sqlsel = 'select * from orderdetail where orderdetailkey = ?';
    var inserts = [odekey];

    var sql = mysql.format(sqlsel, inserts);

    connection.query(sql, function (err, data) {
        if (err) {
            console.error(err);
            process.exit(1);
        }
        res.send(JSON.stringify(data));
    });
});


// update
app.post('/orderdetailupdate', function (req, res, ) {
    var odekey = req.body.orderdetailkey;
    var ordkey = req.body.orderkey;
    var mikey = req.body.mitemkey;
    var itquan = req.body.itemquantity;

    var sqlins = "UPDATE orderdetail SET orderdetailkey = ?, orderkey = ?, mitemkey = ?, itemquantity = ?";
    var inserts = [idekey, ordkey, mikey, itquan];
    var sql = mysql.format(sqlins, inserts);

    console.log(sql);
    connection.execute(sql, function (err, result) {
        if (err) throw err;
        console.log("1 record updated");
        res.end();
    });
});



// ACCESS MENU ITEM INFORMATION
// insert
app.post('/menuinsert', function (req, res) {
    var mikey = req.body.mitemkey;
    var miname = req.body.mitemname;
    var midesc = req.body.mitemdescrip;
    var miprice = req.body.mitemprice;
    console.log(mikey);

    var sqlins = "INSERT INTO menuitem (mitemkey, mitemname, mitemdescrip, mitemprice) VALUES(?, ?, ?, ?)";
    var inserts = [mikey, miname, midesc, miprice];
    var sql = mysql.format(sqlins, inserts);

    connection.execute(sql, function (err, result) {
        if (err) throw err;
        console.log("1 record inserted");
        res.redirect('menuiteminsert.html');
        res.end();
    });
});


// search
app.get('/menusearch', function (req, res) {
    var mikey = req.query.mitemkey;
    var miname = req.query.mitemname;
    var midesc = req.query.mitemdescrip;
    var miprice = req.query.mitemprice;

    var selectSQL = 'Select * from menuitem where mitemkey Like ? and mitemname Like ? and mitemdescrip Like ? and mitemprice Like ?';
    var selects = ['%' + mikey + '%', '%' + miname + '%', '%' + midesc + '%', '%' + miprice + '%'];
    var sql = mysql.format(selectSQL, selects);

    console.log(sql);
    console.log(selects);
    connection.query(sql, function (err, data) {
        if (err) {
            console.error(err);
            process.exit(1);  }
        res.send(JSON.stringify(data));
    });
});


// get a single menu item
app.get('/getsinglemenuitem/', function (req, res) {

    var mkey = req.query.mitemkey;

    var sqlsel = 'select * from menuitem where mitemkey = ?';
    var inserts = [uid];

    var sql = mysql.format(sqlsel, inserts);

    connection.query(sql, function (err, data) {
        if (err) {
            console.error(err);
            process.exit(1);
        }
        res.send(JSON.stringify(data));
    });
});


// update
app.post('/menuupdate', function (req, res, ) {
    var mikey = req.body.mitemkey;
    var miname = req.body.mitemname;
    var midesc = req.body.mitemdescrip;
    var miprice = req.body.mitemprice;

    var sqlins = "UPDATE menuitem SET mitemkey = ?, mitemname = ?, mitemdescrip = ?, mitemprice = ?";
    var inserts = [mikey, miname, midesc, miprice];
    var sql = mysql.format(sqlins, inserts);

    console.log(sql);
    connection.execute(sql, function (err, result) {
        if (err) throw err;
        console.log("1 record updated");
        res.end();
    });
});



// ACCESS INVENTORY INFORMATION
// insert
app.post('/invinsert', function (req, res) {
    var invid = req.body.invid;
    var invname = req.body.invname;
    var invdesc = req.body.invdescrip;
    var invprice = req.body.invunitprice;
    var invidate = req.body.invindate;
    var invodate = req.body.invoutdate;
    var invstock = req.body.invquantityinstock;
    var invsupp = req.body.invsupplier;
    console.log(invid);

    var sqlins = "INSERT INTO inventory (invid, invname, invdescrip, invunitprice, invindate, invoutdate, invquantityinstock, invsupplier) VALUES(?, ?, ?, ?, ?, ?, ?, ?)";
    var inserts = [invid, invname, invdesc, invprice, invidate, invodate, invstock, invsupp];
    var sql = mysql.format(sqlins, inserts);

    connection.execute(sql, function (err, result) {
        if (err) throw err;
        console.log("1 record inserted");
        res.redirect('inventoryinsert.html');
        res.end();
    });
});


// search
app.get('/invsearch', function (req, res) {
    var invid = req.query.invid;
    var invname = req.query.invname;
    var invdesc = req.query.invdescrip;
    var invprice = req.query.invunitprice;
    var invidate = req.query.invindate;
    var invodate = req.query.invoutdate;
    var invstock = req.query.invquantityinstock;
    var invsupp = req.query.invsupplier;

    var selectSQL = 'Select * from inventory where invid Like ? and invname Like ? and invdescrip Like ? and invunitprice Like ? and invindate Like ? and invoutdate Like ? ' +
        'and invquantityinstock Like ? and invsupplier Like ?';
    var selects = ['%' + invid + '%', '%' + invname + '%', '%' + invdesc + '%', '%' + invprice + '%', '%' + invidate + '%', '%' + invodate + '%', '%' + invprice + '%'
                    , '%' + invstock + '%', '%' + invsupp + '%'];
    var sql = mysql.format(selectSQL, selects);

    console.log(sql);
    console.log(selects);
    connection.query(sql, function (err, data) {
        if (err) {
            console.error(err);
            process.exit(1); }
        res.send(JSON.stringify(data));
    });
});


// get a single item from inventory
app.get('/getsingleinvitem/', function (req, res) {

    var invid = req.query.invid;

    var sqlsel = 'select * from inventory where invid = ?';
    var inserts = [invid];

    var sql = mysql.format(sqlsel, inserts);

    connection.query(sql, function (err, data) {
        if (err) {
            console.error(err);
            process.exit(1);
        }
        res.send(JSON.stringify(data));
    });
});


// update
app.post('/invupdate', function (req, res, ) {
    var invid = req.body.invid;
    var invname = req.body.invname;
    var invdesc = req.body.invdescrip;
    var invprice = req.body.invunitprice;
    var invidate = req.body.invindate;
    var invodate = req.body.invoutdate;
    var invstock = req.body.invquantityinstock;
    var invsupp = req.body.invsupplier;

    var sqlins = "UPDATE inventory SET invid = ?, invname = ?, invdescrip = ?, invunitprice = ?, invindate = ?, invoutdate = ?, invquantityinstock = ?, invsupplier = ?";
    var inserts = [invid, invname, invdesc, invprice, invidate, invodate, invstock, invsupp];
    var sql = mysql.format(sqlins, inserts);

    console.log(sql);
    connection.execute(sql, function (err, result) {
        if (err) throw err;
        console.log("1 record updated");
        res.end();
    });
});



// GET PORT
app.listen(app.get('port'), function () {
    console.log('Server started: http://localhost:' + app.get('port') + '/');
});